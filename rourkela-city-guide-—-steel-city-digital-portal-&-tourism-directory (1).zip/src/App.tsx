/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { DIRECTORY_DATA } from './data/rourkelaData';
import { DirectoryItem, CategoryType, LocalityType } from './types/directory';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { InteractiveMap } from './components/InteractiveMap';
import { DirectoryView } from './components/DirectoryView';
import { DetailModal } from './components/DetailModal';
import { NeighbourhoodsSection } from './components/NeighbourhoodsSection';
import { EmergencyModal } from './components/EmergencyModal';
import { SubmitListingModal } from './components/SubmitListingModal';
import { TransportGuide } from './components/TransportGuide';
import { JobsAndBusiness } from './components/JobsAndBusiness';
import { CultureEvents } from './components/CultureEvents';
import { AboutRourkela } from './components/AboutRourkela';
import { Footer } from './components/Footer';
import { PhoneCall, MapPin, ArrowUp } from 'lucide-react';

export default function App() {
  const [items, setItems] = useState<DirectoryItem[]>(DIRECTORY_DATA);
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Modals state
  const [selectedDetailItem, setSelectedDetailItem] = useState<DirectoryItem | null>(null);
  const [selectedMapItem, setSelectedMapItem] = useState<DirectoryItem | null>(null);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState<boolean>(false);
  const [isSubmitOpen, setIsSubmitOpen] = useState<boolean>(false);
  const [prefillItem, setPrefillItem] = useState<DirectoryItem | null>(null);
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Load user submissions from localStorage on start
  useEffect(() => {
    try {
      const stored = localStorage.getItem('rourkela_user_submissions');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setItems([...DIRECTORY_DATA, ...parsed]);
        }
      }
    } catch (e) {
      console.warn('Could not read user submissions', e);
    }
  }, []);

  // Track scroll for back-to-top button
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handle Tab navigation
  const handleSelectTab = (tab: string) => {
    setActiveTab(tab);
    if (tab === 'attractions') {
      setSelectedCategory('attractions');
    } else if (tab === 'education') {
      setSelectedCategory('schools');
    } else if (tab === 'health') {
      setSelectedCategory('hospitals');
    } else if (tab === 'dining') {
      setSelectedCategory('restaurants');
    } else if (tab === 'hotels') {
      setSelectedCategory('hotels');
    } else if (tab === 'transport') {
      setSelectedCategory('transport');
    } else if (tab === 'business') {
      setSelectedCategory('industry');
    } else if (tab === 'overview') {
      setSelectedCategory('all');
    }
  };

  const handleHeroCategorySelect = (catId: string) => {
    if (catId === 'attractions') {
      setSelectedCategory('attractions');
      setActiveTab('attractions');
    } else if (catId === 'education') {
      setSelectedCategory('schools');
      setActiveTab('education');
    } else if (catId === 'health') {
      setSelectedCategory('hospitals');
      setActiveTab('health');
    } else if (catId === 'dining') {
      setSelectedCategory('restaurants');
      setActiveTab('dining');
    } else if (catId === 'hotels') {
      setSelectedCategory('hotels');
      setActiveTab('hotels');
    } else if (catId === 'transport') {
      setSelectedCategory('transport');
      setActiveTab('transport');
    } else if (catId === 'shopping') {
      setSelectedCategory('shopping');
      setActiveTab('overview');
    } else if (catId === 'business') {
      setSelectedCategory('industry');
      setActiveTab('business');
    } else {
      setSelectedCategory('all');
      setActiveTab('overview');
    }

    // Scroll smoothly to directory section
    const dirElement = document.getElementById('directory-section');
    if (dirElement) {
      dirElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleLocateOnMap = (item: DirectoryItem) => {
    setSelectedMapItem(item);
    setActiveTab('map');
    const mapElement = document.getElementById('map-section');
    if (mapElement) {
      mapElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleNeighbourhoodSelect = (localityName: LocalityType) => {
    setActiveTab('overview');
    setSelectedCategory('all');
    setSearchQuery(localityName);
    const dirElement = document.getElementById('directory-section');
    if (dirElement) {
      dirElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSuggestEdit = (item: DirectoryItem) => {
    setPrefillItem(item);
    setIsSubmitOpen(true);
  };

  const handleListingAdded = (newItem: DirectoryItem) => {
    setItems((prev) => [newItem, ...prev]);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-sky-500 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={handleSelectTab}
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenSubmit={() => {
          setPrefillItem(null);
          setIsSubmitOpen(true);
        }}
      />

      <main className="flex-1">
        {/* Hero Section */}
        <HeroSection
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          onSelectCategory={handleHeroCategorySelect}
          onOpenMap={() => {
            setActiveTab('map');
            document.getElementById('map-section')?.scrollIntoView({ behavior: 'smooth' });
          }}
          onOpenEmergency={() => setIsEmergencyOpen(true)}
        />

        {/* Interactive Map (Featured when tab === 'map' or on overview) */}
        <div id="map-section">
          <InteractiveMap
            items={items}
            selectedItem={selectedMapItem}
            onSelectItem={(item) => setSelectedDetailItem(item)}
          />
        </div>

        {/* Directory Section with Search & Category Filters */}
        <div id="directory-section">
          <DirectoryView
            items={items}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onSelectItem={(item) => setSelectedDetailItem(item)}
            onLocateOnMap={handleLocateOnMap}
          />
        </div>

        {/* Transport Guide (Prominent if activeTab === 'transport' or in overview) */}
        {(activeTab === 'overview' || activeTab === 'transport') && (
          <TransportGuide />
        )}

        {/* Searchable Neighbourhoods Section */}
        {(activeTab === 'overview' || activeTab === 'neighbourhoods') && (
          <NeighbourhoodsSection onSelectLocality={handleNeighbourhoodSelect} />
        )}

        {/* Jobs, Industry & SAIL Career Section */}
        {(activeTab === 'overview' || activeTab === 'business') && (
          <JobsAndBusiness />
        )}

        {/* Culture, Hockey Legacy & Local Food Section */}
        {(activeTab === 'overview' || activeTab === 'dining' || activeTab === 'attractions') && (
          <CultureEvents />
        )}

        {/* About Rourkela City Overview & Census Demographics */}
        <AboutRourkela />
      </main>

      {/* Footer */}
      <Footer
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenSubmit={() => {
          setPrefillItem(null);
          setIsSubmitOpen(true);
        }}
        onSelectTab={handleSelectTab}
      />

      {/* Floating Emergency SOS Button on bottom right */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-2">
        {showScrollTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="w-11 h-11 rounded-full bg-white text-slate-700 hover:text-slate-900 border border-slate-300 shadow-md flex items-center justify-center transition-all hover:scale-105"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-5 h-5" />
          </button>
        )}

        <button
          onClick={() => setIsEmergencyOpen(true)}
          className="bg-rose-600 hover:bg-rose-700 text-white font-bold p-3.5 sm:px-4 sm:py-3 rounded-full shadow-xl flex items-center gap-2 transition-all hover:scale-105 animate-pulse"
          aria-label="Emergency hotlines"
        >
          <PhoneCall className="w-5 h-5" />
          <span className="hidden sm:inline text-xs">24/7 Emergency</span>
        </button>
      </div>

      {/* Detail Modal */}
      {selectedDetailItem && (
        <DetailModal
          item={selectedDetailItem}
          onClose={() => setSelectedDetailItem(null)}
          onSuggestEdit={handleSuggestEdit}
        />
      )}

      {/* Emergency Modal */}
      <EmergencyModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
      />

      {/* Submit / Suggest Edit Modal */}
      <SubmitListingModal
        isOpen={isSubmitOpen}
        onClose={() => setIsSubmitOpen(false)}
        prefillItem={prefillItem}
        onListingAdded={handleListingAdded}
      />
    </div>
  );
}
