import React from 'react';
import { CITY_OVERVIEW, POPULATION_STATS } from '../data/rourkelaData';
import { 
  Building, 
  MapPin, 
  Compass, 
  Users, 
  Layers, 
  Sparkles, 
  ShieldCheck, 
  Award 
} from 'lucide-react';

export const AboutRourkela: React.FC = () => {
  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-slate-200">
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-bold mb-2">
          <Compass className="w-3.5 h-3.5" />
          <span>City Overview & Demographic Documentation</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
          About Rourkela: The Steel City of Odisha
        </h2>
        <p className="text-sm text-slate-600 mt-1 max-w-2xl">
          An essential hub of modern industry, premier technical education, advanced healthcare, and international sporting legacy in Western Odisha.
        </p>
      </div>

      {/* Overview Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
        {/* Core Profile Card */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <h3 className="text-lg font-bold text-slate-900 font-display">
            Geographic & Institutional Profile
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Rourkela is situated in the north-western mineral-rich belt of Odisha in Sundargarh district, encircled by undulating forested hills and fed by the sacred rivers Sankha and Koel. Founded around a quiet tribal hamlet in the 1950s, Rourkela transformed rapidly when India's first public sector integrated steel plant was established with German technical collaboration (Krupp and Demag). Today, it stands as an epitome of planned urban design, high civic literacy, and national integration.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-slate-400 block mb-0.5">State & District</span>
              <strong className="text-slate-800 text-sm">{CITY_OVERVIEW.state}, {CITY_OVERVIEW.district} Dist</strong>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-slate-400 block mb-0.5">Popular Identity</span>
              <strong className="text-slate-800 text-sm">{CITY_OVERVIEW.popularIdentity}</strong>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-slate-400 block mb-0.5">Rivers & Geography</span>
              <strong className="text-slate-800 leading-snug">{CITY_OVERVIEW.rivers}</strong>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-slate-400 block mb-0.5">Languages Spoken</span>
              <strong className="text-slate-800">{CITY_OVERVIEW.languages.join(', ')}</strong>
            </div>
          </div>
        </div>

        {/* Heritage & German Engineering Highlights */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-sky-400 text-xs font-bold uppercase mb-2">
              <Award className="w-4 h-4" />
              <span>Historic Foundation</span>
            </div>
            <h3 className="text-lg font-bold text-white mb-2 font-display">
              Indo-German Industrial Heritage
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed font-light mb-4">
              In 1955, the Government of India entered into an agreement with German consortium Krupp & Demag to erect Asia's first steel plant using the advanced Linz-Donawitz (LD) basic oxygen steelmaking process. The planned steel township was designed with German urban zoning standards—creating leafy sectors 1 through 20 with isolated residential, educational, and medical enclaves.
            </p>
          </div>

          <div className="pt-3 border-t border-slate-700 text-xs text-slate-400">
            <span>Elevation: <strong>219m (719 ft) above sea level</strong></span>
          </div>
        </div>
      </div>

      {/* Accurately Labelled Demographics as requested in prompt section 1 */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Users className="w-5 h-5 text-sky-600" />
          <h3 className="text-lg font-bold text-slate-900 font-display">
            Accredited Demographic & Census Data (Area-Disaggregated)
          </h3>
        </div>
        <p className="text-xs text-slate-500 mb-4 max-w-2xl">
          *Note on urban statistics: In official census documentation, Rourkela City, the Rourkela Municipal Corporation (RMC) area, and the wider Urban Agglomeration (UA) represent distinct administrative borders.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {POPULATION_STATS.map((stat, i) => (
            <div key={i} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs text-slate-500 font-medium block mb-1">{stat.label}</span>
              <div className="text-2xl font-extrabold text-slate-900 tracking-tight font-display mb-1">
                {stat.value}
              </div>
              <p className="text-xs text-slate-600 mb-2 leading-snug">{stat.subtext}</p>
              <div className="text-[10px] text-slate-400 font-mono">
                Source: {stat.source}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
