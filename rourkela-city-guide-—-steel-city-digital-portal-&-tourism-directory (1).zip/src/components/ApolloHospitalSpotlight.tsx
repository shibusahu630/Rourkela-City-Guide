import React from 'react';
import { 
  HeartPulse, 
  MapPin, 
  Phone, 
  Navigation, 
  CheckCircle2, 
  ExternalLink,
  ShieldAlert,
  Clock,
  Sparkles,
  Stethoscope,
  Building2,
  Ambulance
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';
import { cleanPhoneForDialing } from '../utils/directoryUtils';

interface ApolloHospitalSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  apolloItem?: DirectoryItem;
}

export const ApolloHospitalSpotlight: React.FC<ApolloHospitalSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  apolloItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-blue-900/10 via-sky-800/5 to-slate-900/5 rounded-3xl p-6 sm:p-8 border border-sky-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[16/10] bg-slate-900 group">
            <img
              src="/assets/aistudio/apollo_8216d922.jpg"
              alt="Apollo Super Speciality Hospital, Rourkela - Academic Block & Main Hospital Facility"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-sky-950 flex items-center gap-1.5 shadow-sm">
              <Building2 className="w-3.5 h-3.5 text-sky-600" />
              <span>Tertiary Care & Super Speciality Centre</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-sky-300 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>24/7 Emergency Casualty & Trauma Wing</span>
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Apollo Super Speciality Hospital, Rourkela</h4>
              <p className="text-xs text-slate-300">G Block Road, Sector 19, Steel Township, Rourkela 769005</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 text-sky-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-sky-600" />
            <span>Verified NABH-Standard Multi-Speciality Healthcare Facility</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Apollo Super Speciality Hospital, Rourkela
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            A state-of-the-art super-speciality facility bringing Apollo's renowned clinical standards to western Odisha. Equipped with advanced flat-panel Cath Lab for emergency cardiac angioplasty, laminar-flow modular operation theatres, dedicated intensive care units (ICU/CCU/NICU), and comprehensive diagnostic pathology and radiology.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <HeartPulse className="w-3.5 h-3.5 text-rose-600" />
                <span className="font-medium">Core Clinical Wings</span>
              </div>
              <strong className="text-slate-800 text-sm">Cardiology, Neuro, Ortho & Nephrology</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <MapPin className="w-3.5 h-3.5 text-sky-600" />
                <span className="font-medium">Township Location</span>
              </div>
              <strong className="text-slate-800 text-sm">Sector 19 (Near G Block Road)</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span className="font-medium">24/7 Emergency Line</span>
              </div>
              <strong className="text-rose-700 text-sm">0661-7101108</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <Ambulance className="w-3.5 h-3.5 text-sky-600" />
                <span className="font-medium">OPD & Appointments</span>
              </div>
              <strong className="text-sky-700 text-sm">80690 49758</strong>
            </div>
          </div>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            {apolloItem && (
              <>
                <button
                  onClick={() => onSelectItem(apolloItem)}
                  className="px-4 py-2.5 rounded-xl bg-sky-700 hover:bg-sky-800 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-sm transition-all"
                >
                  <Stethoscope className="w-4 h-4" />
                  <span>View Hospital Details & Doctors</span>
                </button>

                <button
                  onClick={() => onLocateOnMap(apolloItem)}
                  className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shadow-2xs"
                >
                  <Navigation className="w-4 h-4 text-sky-600" />
                  <span>Locate in Sector 19 on Map</span>
                </button>
              </>
            )}

            <a
              href="tel:06617101108"
              className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm transition-all"
            >
              <Phone className="w-4 h-4" />
              <span>Call Emergency: 0661-7101108</span>
            </a>

            <a
              href="https://www.apollohospitals.com"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2.5 rounded-xl text-slate-600 hover:text-slate-900 font-semibold text-xs flex items-center gap-1 hover:underline"
            >
              <span>Apollo Official Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
