import React from 'react';
import { 
  HeartPulse, 
  MapPin, 
  Phone, 
  Navigation, 
  CheckCircle2, 
  ExternalLink,
  Droplets,
  Activity,
  ShieldAlert,
  Clock,
  Sparkles
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';
import { cleanPhoneForDialing } from '../utils/directoryUtils';

interface BloodBankSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  bloodBankItem?: DirectoryItem;
}

export const BloodBankSpotlight: React.FC<BloodBankSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  bloodBankItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-rose-900/10 via-red-800/5 to-slate-900/5 rounded-3xl p-6 sm:p-8 border border-rose-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[16/10] bg-slate-900 group">
            <img
              src="/assets/aistudio/blood_bank_4714262c.webp"
              alt="Ispat General Hospital (IGH) and Rourkela Red Cross Blood Bank premises, Sector 19"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-rose-900 flex items-center gap-1.5 shadow-sm">
              <Droplets className="w-3.5 h-3.5 text-rose-600 fill-rose-600" />
              <span>24/7 Regional Blood Centre & Component Separation Unit</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-rose-300 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>Open 24 Hours • 365 Days</span>
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Rourkela Red Cross & IGH Blood Bank</h4>
              <p className="text-xs text-slate-300">Adjacent to IGH Emergency Casualty, Sector 19, Steel Township</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-100 text-rose-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-rose-600" />
            <span>Certified Regional Transfusion Center (Govt of Odisha & SAIL RSP)</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Rourkela Red Cross & IGH Blood Bank
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Located within the premier <strong>Ispat General Hospital (IGH)</strong> healthcare complex in Sector 19, the Rourkela Red Cross & IGH Blood Bank serves as the life-saving blood transfusion backbone for Sundargarh and adjoining western Odisha districts. Equipped with state-of-the-art apheresis and component separation technology.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <Activity className="w-3.5 h-3.5 text-rose-600" />
                <span className="font-medium">Blood Components</span>
              </div>
              <strong className="text-slate-800 text-sm">PRBC, Single Donor Platelets, FFP, Cryo</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <MapPin className="w-3.5 h-3.5 text-rose-600" />
                <span className="font-medium">Location</span>
              </div>
              <strong className="text-slate-800 text-sm">Sector 19 (Near IGH Casualty Triage)</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <Phone className="w-3.5 h-3.5 text-rose-600" />
                <span className="font-medium">24/7 Blood Bank Helpline</span>
              </div>
              <strong className="text-rose-700 text-sm">0661-2642444</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                <span className="font-medium">Emergency Protocol</span>
              </div>
              <strong className="text-slate-800">Direct cross-matching for trauma & maternity</strong>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <a
              href={`tel:${cleanPhoneForDialing('0661-2642444')}`}
              className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call Blood Bank (0661-2642444)</span>
            </a>

            <a
              href={`tel:${cleanPhoneForDialing('0661-2642222')}`}
              className="px-4 py-2.5 rounded-xl bg-white border border-rose-300 text-rose-900 font-bold text-xs flex items-center gap-2 hover:bg-rose-50 transition-colors"
            >
              <HeartPulse className="w-3.5 h-3.5 text-rose-600" />
              <span>IGH Casualty (0661-2642222)</span>
            </a>

            <a
              href="https://www.google.com/maps/dir/?api=1&destination=22.2472,84.8755"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 font-bold text-xs flex items-center gap-2 transition-colors"
            >
              <Navigation className="w-3.5 h-3.5 text-rose-400" />
              <span>Get Directions</span>
              <ExternalLink className="w-3 h-3" />
            </a>

            {bloodBankItem && (
              <>
                <button
                  onClick={() => onSelectItem(bloodBankItem)}
                  className="px-4 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 transition-colors"
                >
                  View Details
                </button>
                <button
                  onClick={() => onLocateOnMap(bloodBankItem)}
                  className="px-3.5 py-2.5 rounded-xl text-rose-700 hover:text-rose-900 font-bold text-xs flex items-center gap-1.5"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>Locate on Map</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
