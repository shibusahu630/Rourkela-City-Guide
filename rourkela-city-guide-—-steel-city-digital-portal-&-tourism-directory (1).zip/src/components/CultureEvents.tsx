import React from 'react';
import { UPCOMING_EVENTS } from '../data/rourkelaData';
import { 
  Trophy, 
  Calendar, 
  Utensils, 
  Sparkles, 
  MapPin, 
  CheckCircle2, 
  Flame 
} from 'lucide-react';

export const CultureEvents: React.FC = () => {
  const hockeyLegends = [
    { name: 'Dilip Tirkey', title: 'Hockey Legend & Hockey India President', achievement: 'Former Indian Captain, 412 international caps, 3-time Olympian from Sundargarh' },
    { name: 'Amit Rohidas', title: 'Olympic Medalist Defender', achievement: 'Tokyo 2020 & Paris 2024 Olympic Bronze Medalist; cornerstone of Indian defense' },
    { name: 'Birendra Lakra', title: 'Olympic Medalist & Vice-Captain', achievement: 'Tokyo 2020 Olympic Bronze Medalist; stalwart defender' },
    { name: 'Deep Grace Ekka', title: 'Indian Women\'s Hockey Stalwart', achievement: 'Double Olympian, Asian Champions Trophy Gold Medalist' },
  ];

  const regionalDishes = [
    {
      name: 'Chhena Poda',
      type: 'Traditional Odia Confection',
      desc: 'Known as the \'Burnt Cheesecake of Odisha\'. Made of fresh cottage cheese kneaded with sugar, cardamom, and cashew, then slowly caramelized in sal leaves until a fragrant golden-brown crust forms.',
      whereToTry: 'Utkal Chhena Poda Emporium, Basanti Colony & Sector 5 Market'
    },
    {
      name: 'Pakhala Bhata',
      type: 'Summer Heritage Meal',
      desc: 'Cooked rice fermented with water, curd, and tempered with mustard seeds and curry leaves. Served alongside crispy fried fish, saga bhaja (stir-fried leafy greens), badi chura, and roasted potatoes.',
      whereToTry: 'MAYFAIR Odia Lounge, Panposh & local Odia eateries'
    },
    {
      name: 'Machha Besara',
      type: 'Classic River Fish Curry',
      desc: 'Fresh Rohu or Katla fish sourced from the Brahmani River, cooked in a pungent and aromatic mustard paste (\'Besara\') gravy with green chilies, ambula (dried mango) and fresh coriander.',
      whereToTry: 'Traditional dining venues across Civil Township and Panposh'
    },
    {
      name: 'Dahi Bara Aloo Dum',
      type: 'Iconic Evening Street Food',
      desc: 'Soft urad dal dumplings soaked in spiced cooling buttermilk, layered with piping-hot spicy potato and yellow-pea curry, topped with chopped onions, coriander, and sev.',
      whereToTry: 'Basanti Colony Evening Market & Daily Market Uditnagar'
    }
  ];

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-slate-200">
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Heritage, Sports & Culinary Soul</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
          Culture, Hockey Legacy & Local Food
        </h2>
        <p className="text-sm text-slate-600 mt-1 max-w-2xl">
          Rourkela is India\'s celebrated hockey capital, a vibrant crucible of Western Odisha tribal traditions, and a haven for authentic Odia gastronomy.
        </p>
      </div>

      {/* Hockey Legacy Banner with authentic Stadium photograph */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 rounded-3xl text-white p-6 sm:p-8 mb-12 shadow-xl border border-sky-800/40 relative overflow-hidden">
        <div className="flex flex-col lg:flex-row gap-8 items-center mb-6">
          <div className="flex-1">
            <div className="flex items-center gap-2 text-sky-300 text-xs font-bold uppercase tracking-wider mb-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>The Cradle of Indian Hockey • Guinness World Record</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white mb-3 font-display">
              Sundargarh & Birsa Munda Hockey Stadium
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-light mb-4">
              Sundargarh district and Rourkela have nurtured more international Olympians than any other region in India. With the world's largest all-seater field hockey stadium (<strong>20,011 seated capacity</strong>) built in record 15 months for the FIH Men's Hockey World Cup 2023, the city is globally recognized as the modern sanctuary of field hockey.
            </p>
            <div className="flex flex-wrap gap-2 text-xs">
              <span className="bg-white/10 text-sky-200 px-3 py-1 rounded-lg border border-white/10 font-semibold">
                Guinness Record 20,011 Capacity
              </span>
              <span className="bg-white/10 text-sky-200 px-3 py-1 rounded-lg border border-white/10 font-semibold">
                FIH Category 1 Olympic Turf
              </span>
              <span className="bg-white/10 text-sky-200 px-3 py-1 rounded-lg border border-white/10 font-semibold">
                BPUT Campus, Sector 15
              </span>
            </div>
          </div>

          {/* Photo Showcase */}
          <div className="w-full lg:w-96 shrink-0">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-2 border-white/20 aspect-[4/3] group">
              <img
                src="/assets/aistudio/birsa_munda_hockey_stadium_ca04fe4b.webp"
                alt="Birsa Munda International Hockey Stadium Rourkela"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
              <div className="absolute bottom-2.5 left-3 right-3 text-white text-xs">
                <span className="font-bold block text-sm">Birsa Munda Stadium Spectator Pavilion</span>
                <span className="text-[11px] text-sky-300">East, West, North, South Stands & Olly\'s Land</span>
              </div>
            </div>
          </div>
        </div>

        {/* Hockey Legends */}
        <div className="pt-6 border-t border-white/10">
          <h4 className="text-xs font-bold uppercase tracking-wider text-sky-300 mb-3">
            Living Legends of Sundargarh Hockey:
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {hockeyLegends.map((legend, i) => (
              <div key={i} className="bg-white/10 backdrop-blur-md p-3.5 rounded-xl border border-white/10">
                <h4 className="font-bold text-white text-sm">{legend.name}</h4>
                <p className="text-[11px] text-sky-300 font-medium mb-1">{legend.title}</p>
                <p className="text-[11px] text-slate-300 leading-snug">{legend.achievement}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Events Calendar */}
      <div className="mb-12">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-slate-900 font-display flex items-center gap-2">
            <Calendar className="w-5 h-5 text-sky-600" />
            <span>Verified Upcoming Events & Festivals</span>
          </h3>
          <span className="text-xs text-slate-500">Cross-checked dates</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {UPCOMING_EVENTS.map((event) => (
            <div
              key={event.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-sky-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-sky-100 text-sky-800 uppercase tracking-wider">
                    {event.category}
                  </span>
                  <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    {event.date}
                  </span>
                </div>

                <h4 className="text-base font-bold text-slate-900 mb-1">
                  {event.title}
                </h4>

                <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{event.venue}</span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed mb-3">
                  {event.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-slate-500 truncate mr-2">
                  Organiser: <strong>{event.organizer}</strong>
                </span>
                <span className="text-sky-700 font-medium shrink-0">
                  {event.ticketInfo}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Odia Food Culture */}
      <div>
        <div className="flex items-center gap-2 text-slate-900 mb-4">
          <Utensils className="w-5 h-5 text-amber-600" />
          <h3 className="text-lg font-bold font-display">
            Authentic Odia Culinary Gems in Rourkela
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {regionalDishes.map((dish, i) => (
            <div key={i} className="bg-amber-50/50 rounded-2xl p-5 border border-amber-200/70">
              <div className="flex items-baseline justify-between mb-1">
                <h4 className="text-base font-bold text-slate-900">{dish.name}</h4>
              </div>
              <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider block mb-2">
                {dish.type}
              </span>
              <p className="text-xs text-slate-600 leading-relaxed mb-3">
                {dish.desc}
              </p>
              <div className="text-[11px] text-amber-950 bg-white p-2 rounded-lg border border-amber-200">
                <strong>Where to try:</strong> {dish.whereToTry}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
