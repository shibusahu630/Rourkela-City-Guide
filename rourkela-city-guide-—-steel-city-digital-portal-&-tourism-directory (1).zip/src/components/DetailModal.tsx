import React, { useState } from 'react';
import { 
  DirectoryItem 
} from '../types/directory';
import { 
  X, 
  MapPin, 
  Phone, 
  Globe, 
  Clock, 
  Star, 
  CheckCircle2, 
  Navigation, 
  Copy, 
  Check, 
  AlertCircle, 
  HeartPulse, 
  GraduationCap, 
  ShieldCheck, 
  Bed, 
  Utensils, 
  Briefcase 
} from 'lucide-react';
import { cleanPhoneForDialing } from '../utils/directoryUtils';

interface DetailModalProps {
  item: DirectoryItem | null;
  onClose: () => void;
  onSuggestEdit: (item: DirectoryItem) => void;
}

export const DetailModal: React.FC<DetailModalProps> = ({
  item,
  onClose,
  onSuggestEdit
}) => {
  const [copied, setCopied] = useState(false);

  if (!item) return null;

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(`${item.name}, ${item.address}, Rourkela`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="relative bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] flex flex-col"
        role="dialog"
        aria-labelledby="modal-title"
      >
        {/* Header Image or Gradient */}
        <div className="relative h-48 sm:h-56 bg-slate-900 shrink-0">
          {item.imageUrl ? (
            <img
              src={item.imageUrl}
              alt={item.name}
              className="w-full h-full object-cover opacity-90"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-tr from-sky-700 to-indigo-900 flex items-center justify-center text-white/20">
              <MapPin className="w-20 h-20" />
            </div>
          )}

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/50 text-white hover:bg-black/80 transition-colors backdrop-blur-md"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Badges on image */}
          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
            <div className="flex flex-wrap gap-2">
              <span className="bg-sky-600 text-white text-xs font-bold px-3 py-1 rounded-lg uppercase tracking-wider shadow-sm">
                {item.subcategory}
              </span>
              {item.verified && (
                <span className="bg-emerald-600 text-white text-xs font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 shadow-sm">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Verified Official
                </span>
              )}
            </div>

            {item.priceRange && (
              <span className="bg-slate-900/80 backdrop-blur-md text-white text-xs font-bold px-2.5 py-1 rounded-lg">
                {item.priceRange}
              </span>
            )}
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-6 space-y-6">
          {/* Title & Ratings */}
          <div>
            <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
              <h3 id="modal-title" className="text-2xl font-extrabold text-slate-900 tracking-tight font-display">
                {item.name}
              </h3>
              {item.rating && (
                <div className="flex items-center gap-1.5 shrink-0 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                  <span className="font-bold text-slate-900 text-sm">{item.rating}</span>
                  {item.reviewsCount && (
                    <span className="text-xs text-slate-500">
                      ({item.reviewsCount.toLocaleString()} reviews)
                    </span>
                  )}
                </div>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Neighbourhood: <strong className="text-slate-700">{item.locality}</strong>
              {item.verifiedDate && ` • Last verified on ${item.verifiedDate}`}
            </p>
          </div>

          {/* Emergency Alert Banner (for hospitals & healthcare) */}
          {item.category === 'hospitals' && (
            <div className={`p-4 rounded-2xl flex items-start gap-3 border ${
              item.emergencyAvailable 
                ? 'bg-rose-50 border-rose-200 text-rose-900' 
                : 'bg-amber-50 border-amber-200 text-amber-900'
            }`}>
              <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-rose-600" />
              <div className="text-xs">
                <strong className="block text-sm font-bold mb-0.5">
                  {item.emergencyAvailable ? '24-Hour Emergency Department' : 'Hospital OPD / Clinic Service'}
                </strong>
                <p>
                  {item.emergencyAvailable
                    ? 'Verified 24/7 casualty and critical care triage. Direct emergency contact numbers are listed below.'
                    : 'For life-threatening emergencies, do not visit outpatient clinics. Immediately dial 112 or visit Ispat General Hospital (IGH) Casualty.'}
                </p>
              </div>
            </div>
          )}

          {/* Quick Contact & Directions Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200">
            {/* Phone */}
            {item.phone && (
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700 shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="text-[11px] text-slate-500 block">General Contact</span>
                  <a
                    href={`tel:${cleanPhoneForDialing(item.phone)}`}
                    className="text-xs sm:text-sm font-bold text-emerald-700 hover:underline block truncate"
                  >
                    {item.phone}
                  </a>
                </div>
              </div>
            )}

            {/* Emergency Phone if available */}
            {item.emergencyPhone && (
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-rose-100 flex items-center justify-center text-rose-700 shrink-0">
                  <HeartPulse className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="text-[11px] text-rose-600 font-semibold block">Emergency Hotline</span>
                  <a
                    href={`tel:${cleanPhoneForDialing(item.emergencyPhone)}`}
                    className="text-xs sm:text-sm font-bold text-rose-700 hover:underline block truncate"
                  >
                    {item.emergencyPhone}
                  </a>
                </div>
              </div>
            )}

            {/* Operating Hours */}
            {item.timing && (
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-sky-100 flex items-center justify-center text-sky-700 shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="text-[11px] text-slate-500 block">Timings / Hours</span>
                  <span className="text-xs font-semibold text-slate-800 block truncate">
                    {item.timing}
                  </span>
                </div>
              </div>
            )}

            {/* Official Website */}
            {item.website && (
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-700 shrink-0">
                  <Globe className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="text-[11px] text-slate-500 block">Official Website</span>
                  <a
                    href={item.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-bold text-indigo-600 hover:underline block truncate"
                  >
                    Visit Website ↗
                  </a>
                </div>
              </div>
            )}
          </div>

          {/* Address with copy & Google Directions button */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white border border-slate-200">
            <div className="flex items-start gap-2.5">
              <MapPin className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
              <div className="text-xs text-slate-700">
                <strong className="block font-semibold text-slate-900">Verified Address:</strong>
                <span>{item.address}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
              <button
                onClick={handleCopyAddress}
                className="flex-1 sm:flex-none text-xs font-semibold px-3 py-2 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 flex items-center justify-center gap-1.5 transition-colors"
                title="Copy Address"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>

              <a
                href={`https://www.google.com/maps/dir/?api=1&destination=${item.coordinates[0]},${item.coordinates[1]}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 sm:flex-none text-xs font-bold px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white flex items-center justify-center gap-1.5 shadow-sm transition-colors"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Directions ↗</span>
              </a>
            </div>
          </div>

          {/* Description */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 mb-2">Overview & Details</h4>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {item.description}
            </p>
          </div>

          {/* Key Highlights */}
          {item.highlights && item.highlights.length > 0 && (
            <div>
              <h4 className="text-sm font-bold text-slate-900 mb-2">Key Features & Highlights</h4>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-700">
                {item.highlights.map((h, i) => (
                  <li key={i} className="flex items-start gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{h}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Category-Specific Modules */}
          {item.affiliation && (
            <div className="p-4 rounded-2xl bg-sky-50/80 border border-sky-100">
              <div className="flex items-center gap-2 text-sky-900 font-bold text-xs mb-1">
                <GraduationCap className="w-4 h-4 text-sky-600" />
                <span>Affiliation & Board / Accreditation</span>
              </div>
              <p className="text-xs text-sky-800">{item.affiliation}</p>
              {item.degreesOffered && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {item.degreesOffered.map((deg, i) => (
                    <span key={i} className="text-[10px] bg-white text-sky-800 px-2 py-0.5 rounded font-medium border border-sky-200">
                      {deg}
                    </span>
                  ))}
                </div>
              )}
            </div>
          )}

          {item.cuisine && (
            <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-100">
              <div className="flex items-center gap-2 text-amber-900 font-bold text-xs mb-1">
                <Utensils className="w-4 h-4 text-amber-600" />
                <span>Cuisines & Dining Specialities</span>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {item.cuisine.map((c, i) => (
                  <span key={i} className="text-xs bg-white text-amber-800 px-2.5 py-1 rounded-lg font-medium border border-amber-200">
                    {c}
                  </span>
                ))}
              </div>
            </div>
          )}

          {item.amenities && (
            <div className="p-4 rounded-2xl bg-purple-50/80 border border-purple-100">
              <div className="flex items-center gap-2 text-purple-900 font-bold text-xs mb-2">
                <Bed className="w-4 h-4 text-purple-600" />
                <span>Hotel Amenities & Facilities</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5 text-xs text-purple-800">
                {item.amenities.map((amenity, i) => (
                  <span key={i} className="flex items-center gap-1.5">
                    • {amenity}
                  </span>
                ))}
              </div>
            </div>
          )}

          {item.jobOpportunities && (
            <div className="p-4 rounded-2xl bg-slate-100 border border-slate-200">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-xs mb-1">
                <Briefcase className="w-4 h-4 text-slate-700" />
                <span>Recruitment, Careers & Apprenticeship Guidance</span>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">{item.jobOpportunities}</p>
            </div>
          )}

          {/* Tags */}
          <div className="flex flex-wrap gap-1.5 pt-2">
            {item.tags.map((tag, i) => (
              <span key={i} className="text-[11px] bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full">
                #{tag}
              </span>
            ))}
          </div>
        </div>

        {/* Modal Footer with Suggest Edit */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <button
            onClick={() => {
              onClose();
              onSuggestEdit(item);
            }}
            className="text-xs text-slate-600 hover:text-slate-900 font-semibold underline flex items-center gap-1"
          >
            <span>Suggest an Edit or Report Incorrect Data</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
