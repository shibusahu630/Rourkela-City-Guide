import React, { useState } from 'react';
import { 
  DirectoryItem, 
  CategoryType, 
  LocalityType 
} from '../types/directory';
import { 
  Search, 
  MapPin, 
  Phone, 
  Star, 
  CheckCircle2, 
  Clock, 
  ExternalLink, 
  Navigation, 
  SlidersHorizontal, 
  Sparkles, 
  Compass, 
  GraduationCap, 
  HeartPulse, 
  UtensilsCrossed, 
  BedDouble, 
  Train, 
  ShoppingBag, 
  Factory,
  AlertTriangle
} from 'lucide-react';
import { filterDirectoryItems, cleanPhoneForDialing } from '../utils/directoryUtils';
import { HanumanVatikaSpotlight } from './HanumanVatikaSpotlight';
import { StadiumSpotlight } from './StadiumSpotlight';
import { KhandadharSpotlight } from './KhandadharSpotlight';
import { NitRourkelaSpotlight } from './NitRourkelaSpotlight';
import { RimsSpotlight } from './RimsSpotlight';
import { BloodBankSpotlight } from './BloodBankSpotlight';
import { ApolloHospitalSpotlight } from './ApolloHospitalSpotlight';
import { JpHospitalSpotlight } from './JpHospitalSpotlight';
import { RghHospitalSpotlight } from './RghHospitalSpotlight';
import { VedvyasSpotlight } from './VedvyasSpotlight';
import { RspSteelPlantSpotlight } from './RspSteelPlantSpotlight';
import { VaishnodeviSpotlight } from './VaishnodeviSpotlight';
import { MandiraDamSpotlight } from './MandiraDamSpotlight';
import { IgParkSpotlight } from './IgParkSpotlight';
import { PitamahalSpotlight } from './PitamahalSpotlight';

interface DirectoryViewProps {
  items: DirectoryItem[];
  selectedCategory: CategoryType;
  setSelectedCategory: (cat: CategoryType) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
}

export const DirectoryView: React.FC<DirectoryViewProps> = ({
  items,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
  onSelectItem,
  onLocateOnMap
}) => {
  const [selectedLocality, setSelectedLocality] = useState<LocalityType | 'All Localities'>('All Localities');
  const [dietaryFilter, setDietaryFilter] = useState<string>('');
  const [verifiedOnly, setVerifiedOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'rating' | 'reviews' | 'name'>('rating');

  const filteredItems = filterDirectoryItems(items, {
    query: searchQuery,
    category: selectedCategory,
    locality: selectedLocality,
    dietary: dietaryFilter,
    verifiedOnly,
    sortBy
  });

  const categories: { id: CategoryType; label: string; icon: any }[] = [
    { id: 'all', label: 'All Listings', icon: Sparkles },
    { id: 'attractions', label: 'Tourist Places', icon: Compass },
    { id: 'schools', label: 'Schools', icon: GraduationCap },
    { id: 'colleges', label: 'Colleges & NIT', icon: GraduationCap },
    { id: 'hospitals', label: 'Hospitals & Health', icon: HeartPulse },
    { id: 'restaurants', label: 'Food & Dining', icon: UtensilsCrossed },
    { id: 'hotels', label: 'Hotels & Stay', icon: BedDouble },
    { id: 'transport', label: 'Railway & Transit', icon: Train },
    { id: 'shopping', label: 'Markets & Malls', icon: ShoppingBag },
    { id: 'industry', label: 'Jobs & Industry', icon: Factory },
  ];

  const localities: (LocalityType | 'All Localities')[] = [
    'All Localities',
    'Civil Township',
    'Uditnagar',
    'Chhend Colony',
    'Koel Nagar',
    'Basanti Colony',
    'Sector 1-20 (Steel Township)',
    'Panposh',
    'Jagda',
    'Bondamunda',
    'Kalunga',
    'Fertilizer Township',
    'Birsa Munda / Nayabazar Area',
    'Wider Sundargarh'
  ];

  const [activeLandmark, setActiveLandmark] = useState<'hanuman' | 'stadium' | 'khandadhar' | 'nit' | 'rims' | 'bloodbank' | 'apollo' | 'jp' | 'rgh' | 'vedvyas' | 'rsp' | 'vaishnodevi' | 'mandira' | 'igpark' | 'pitamahal'>('hanuman');

  const hanumanVatikaItem = items.find(i => i.id === 'tourist-hanuman-vatika');
  const stadiumItem = items.find(i => i.id === 'tourist-birsa-munda-stadium');
  const khandadharItem = items.find(i => i.id === 'tourist-khandadhar-falls');
  const vedvyasItem = items.find(i => i.id === 'tourist-vedvyas-temple');
  const rspSteelPlantItem = items.find(i => i.id === 'tourist-rourkela-steel-plant');
  const vaishnodeviItem = items.find(i => i.id === 'tourist-vaishnodevi-temple');
  const mandiraDamItem = items.find(i => i.id === 'tourist-mandira-dam');
  const igParkItem = items.find(i => i.id === 'tourist-ig-park');
  const pitamahalItem = items.find(i => i.id === 'tourist-pitamahal-dam');
  const nitRourkelaItem = items.find(i => i.id === 'college-nit-rourkela');
  const rimsItem = items.find(i => i.id === 'college-rims-chhend');
  const bloodBankItem = items.find(i => i.id === 'health-blood-bank');
  const apolloHospitalItem = items.find(i => i.id === 'health-apollo-rourkela');
  const jpHospitalItem = items.find(i => i.id === 'health-jp-hospital');
  const rghHospitalItem = items.find(i => i.id === 'health-rgh-panposh');

  const queryLower = searchQuery.toLowerCase();
  const isPitamahalQuery = queryLower.includes('pitamahal') || queryLower.includes('kalunga dam') || queryLower.includes('nature reserve');
  const isIgParkQuery = queryLower.includes('indira gandhi') || queryLower.includes('ig park') || queryLower.includes('musical fountain') || queryLower.includes('toy train') || queryLower.includes('deer park') || queryLower.includes('botanical');
  const isMandiraQuery = queryLower.includes('mandira') || queryLower.includes('reservoir') || queryLower.includes('sankha dam') || queryLower.includes('spillway') || (queryLower.includes('dam') && !queryLower.includes('durgapur') && !queryLower.includes('pitamahal'));
  const isVaishnodeviQuery = queryLower.includes('vaishno') || queryLower.includes('vaishnodevi') || queryLower.includes('durgapur') || queryLower.includes('hill top') || queryLower.includes('hilltop') || queryLower.includes('cave temple') || queryLower.includes('trikuta');
  const isRspQuery = queryLower.includes('rsp') || queryLower.includes('steel plant') || queryLower.includes('sail') || queryLower.includes('rolling mill') || queryLower.includes('blast furnace') || queryLower.includes('sinter') || queryLower.includes('krupp') || queryLower.includes('ld process');
  const isVedvyasQuery = queryLower.includes('vedvyas') || queryLower.includes('vedavyas') || queryLower.includes('confluence') || queryLower.includes('brahmani') || queryLower.includes('vyasa') || queryLower.includes('sankha');
  const isStadiumQuery = queryLower.includes('hockey') || queryLower.includes('stadium') || queryLower.includes('birsa');
  const isHanumanQuery = queryLower.includes('hanuman') || queryLower.includes('vatika');
  const isKhandadharQuery = queryLower.includes('khandadhar') || queryLower.includes('waterfall') || queryLower.includes('falls');
  const isNitQuery = queryLower.includes('nit') || queryLower.includes('engineering') || queryLower.includes('technology') || queryLower.includes('rec') || queryLower.includes('tiir') || queryLower.includes('incubator');
  const isRimsQuery = queryLower.includes('rims') || queryLower.includes('management studies') || queryLower.includes('b-school') || queryLower.includes('mba');
  const isBloodBankQuery = queryLower.includes('blood') || queryLower.includes('red cross') || queryLower.includes('transfusion') || queryLower.includes('platelet') || queryLower.includes('donor');
  const isApolloQuery = queryLower.includes('apollo') || queryLower.includes('cardiology') || queryLower.includes('angioplasty') || queryLower.includes('cath lab');
  const isJpQuery = queryLower.includes('jp ') || queryLower.includes('jaiprakash') || queryLower.includes('jp hospital') || queryLower.includes('dandiapali');
  const isRghQuery = queryLower.includes('rgh') || queryLower.includes('government hospital') || queryLower.includes('govt hospital') || queryLower.includes('sarkari') || queryLower.includes('panposh road');

  // Determine which landmark spotlight to display
  let currentSpotlight: 'hanuman' | 'stadium' | 'khandadhar' | 'nit' | 'rims' | 'bloodbank' | 'apollo' | 'jp' | 'rgh' | 'vedvyas' | 'rsp' | 'vaishnodevi' | 'mandira' | 'igpark' | 'pitamahal' | null = null;
  if (isPitamahalQuery) {
    currentSpotlight = 'pitamahal';
  } else if (isIgParkQuery) {
    currentSpotlight = 'igpark';
  } else if (isMandiraQuery) {
    currentSpotlight = 'mandira';
  } else if (isVaishnodeviQuery) {
    currentSpotlight = 'vaishnodevi';
  } else if (isRspQuery) {
    currentSpotlight = 'rsp';
  } else if (isVedvyasQuery) {
    currentSpotlight = 'vedvyas';
  } else if (isRghQuery) {
    currentSpotlight = 'rgh';
  } else if (isJpQuery) {
    currentSpotlight = 'jp';
  } else if (isApolloQuery) {
    currentSpotlight = 'apollo';
  } else if (isBloodBankQuery) {
    currentSpotlight = 'bloodbank';
  } else if (isRimsQuery) {
    currentSpotlight = 'rims';
  } else if (isNitQuery) {
    currentSpotlight = 'nit';
  } else if (isKhandadharQuery) {
    currentSpotlight = 'khandadhar';
  } else if (isStadiumQuery) {
    currentSpotlight = 'stadium';
  } else if (isHanumanQuery) {
    currentSpotlight = 'hanuman';
  } else if (selectedCategory === 'industry') {
    currentSpotlight = 'rsp';
  } else if (selectedCategory === 'hospitals') {
    currentSpotlight = activeLandmark === 'bloodbank' 
      ? 'bloodbank' 
      : (activeLandmark === 'jp' 
          ? 'jp' 
          : (activeLandmark === 'rgh' ? 'rgh' : 'apollo'));
  } else if (selectedCategory === 'colleges') {
    currentSpotlight = activeLandmark === 'rims' ? 'rims' : 'nit';
  } else if (selectedCategory === 'attractions') {
    currentSpotlight = (activeLandmark === 'hanuman' || activeLandmark === 'stadium' || activeLandmark === 'khandadhar' || activeLandmark === 'vedvyas' || activeLandmark === 'rsp' || activeLandmark === 'vaishnodevi' || activeLandmark === 'mandira' || activeLandmark === 'igpark' || activeLandmark === 'pitamahal')
      ? activeLandmark
      : 'pitamahal';
  } else if (selectedCategory === 'all' && !searchQuery) {
    currentSpotlight = activeLandmark;
  }

  return (
    <section className="py-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Category selector pill bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6 scrollbar-thin">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                isSelected
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <Icon className={`w-4 h-4 ${isSelected ? 'text-sky-400' : 'text-slate-500'}`} />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Filter and Search controls bar */}
      <div className="bg-white p-4 rounded-2xl shadow-xs border border-slate-200 mb-8 flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search within directory by name, course, specialty, cuisine, tag..."
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/30"
          />
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Locality select */}
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-500 font-medium hidden sm:inline">Locality:</span>
            <select
              value={selectedLocality}
              onChange={(e) => setSelectedLocality(e.target.value as any)}
              className="text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-700 font-medium focus:outline-none"
            >
              {localities.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>

          {/* Restaurant dietary filter */}
          {selectedCategory === 'restaurants' && (
            <select
              value={dietaryFilter}
              onChange={(e) => setDietaryFilter(e.target.value)}
              className="text-xs bg-emerald-50 border border-emerald-300 rounded-xl px-3 py-2 text-emerald-800 font-medium focus:outline-none"
            >
              <option value="">All Dietary</option>
              <option value="Pure Vegetarian">Pure Veg Only</option>
              <option value="Vegetarian">Vegetarian Available</option>
              <option value="Non-Vegetarian">Non-Vegetarian</option>
            </select>
          )}

          {/* Verified toggle */}
          <button
            onClick={() => setVerifiedOnly(!verifiedOnly)}
            className={`text-xs font-semibold px-3 py-2 rounded-xl border flex items-center gap-1.5 transition-colors ${
              verifiedOnly
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                : 'bg-slate-50 text-slate-600 border-slate-300 hover:bg-slate-100'
            }`}
          >
            <CheckCircle2 className={`w-3.5 h-3.5 ${verifiedOnly ? 'text-emerald-600' : 'text-slate-400'}`} />
            <span>Verified Only</span>
          </button>

          {/* Sort selector */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="text-xs bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-700 font-medium focus:outline-none"
          >
            <option value="rating">Sort: Highest Rated</option>
            <option value="reviews">Sort: Most Reviews</option>
            <option value="name">Sort: Alphabetical (A-Z)</option>
          </select>
        </div>
      </div>

      {/* Featured Landmark Spotlights with authentic user-uploaded photographs */}
      {currentSpotlight && (
        <div>
          {/* Quick Landmark Switcher bar when browsing all / attractions */}
          {!searchQuery && (
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Featured Landmark Spotlights:</span>
              </span>
              <div className="inline-flex rounded-xl p-1 bg-slate-100 border border-slate-200 text-xs font-medium">
                <button
                  onClick={() => setActiveLandmark('hanuman')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'hanuman'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🏛️ Hanuman Vatika
                </button>
                <button
                  onClick={() => setActiveLandmark('stadium')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'stadium'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🏑 Birsa Munda Stadium
                </button>
                <button
                  onClick={() => setActiveLandmark('khandadhar')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'khandadhar'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🌊 Khandadhar Waterfall
                </button>
                <button
                  onClick={() => setActiveLandmark('vedvyas')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'vedvyas'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🕉️ Vedvyas Temple
                </button>
                <button
                  onClick={() => setActiveLandmark('nit')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'nit'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🎓 NIT Rourkela
                </button>
                <button
                  onClick={() => setActiveLandmark('rims')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'rims'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  💼 RIMS B-School
                </button>
                <button
                  onClick={() => setActiveLandmark('bloodbank')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'bloodbank'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🩸 Red Cross Blood Bank
                </button>
                <button
                  onClick={() => setActiveLandmark('apollo')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'apollo'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🏥 Apollo Hospital
                </button>
                <button
                  onClick={() => setActiveLandmark('jp')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'jp'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🏥 JP Hospital
                </button>
                <button
                  onClick={() => setActiveLandmark('rgh')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'rgh'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🏥 RGH Govt Hospital
                </button>
                <button
                  onClick={() => setActiveLandmark('rsp')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'rsp'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🏭 RSP Steel Plant
                </button>
                <button
                  onClick={() => setActiveLandmark('vaishnodevi')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'vaishnodevi'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🛕 Maa Vaishnodevi
                </button>
                <button
                  onClick={() => setActiveLandmark('mandira')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'mandira'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🌊 Mandira Dam
                </button>
                <button
                  onClick={() => setActiveLandmark('igpark')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'igpark'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🌳 IG Park & Fountain
                </button>
                <button
                  onClick={() => setActiveLandmark('pitamahal')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    currentSpotlight === 'pitamahal'
                      ? 'bg-white text-slate-900 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  🏞️ Pitamahal Dam
                </button>
              </div>
            </div>
          )}

          {currentSpotlight === 'hanuman' && (
            <HanumanVatikaSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              hanumanVatikaItem={hanumanVatikaItem}
            />
          )}

          {currentSpotlight === 'stadium' && (
            <StadiumSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              stadiumItem={stadiumItem}
            />
          )}

          {currentSpotlight === 'khandadhar' && (
            <KhandadharSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              khandadharItem={khandadharItem}
            />
          )}

          {currentSpotlight === 'nit' && (
            <NitRourkelaSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              nitItem={nitRourkelaItem}
            />
          )}

          {currentSpotlight === 'rims' && (
            <RimsSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              rimsItem={rimsItem}
            />
          )}

          {currentSpotlight === 'bloodbank' && (
            <BloodBankSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              bloodBankItem={bloodBankItem}
            />
          )}

          {currentSpotlight === 'apollo' && (
            <ApolloHospitalSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              apolloItem={apolloHospitalItem}
            />
          )}

          {currentSpotlight === 'jp' && (
            <JpHospitalSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              jpHospitalItem={jpHospitalItem}
            />
          )}

          {currentSpotlight === 'rgh' && (
            <RghHospitalSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              rghItem={rghHospitalItem}
            />
          )}

          {currentSpotlight === 'vedvyas' && (
            <VedvyasSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              vedvyasItem={vedvyasItem}
            />
          )}

          {currentSpotlight === 'rsp' && (
            <RspSteelPlantSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              rspItem={rspSteelPlantItem}
            />
          )}

          {currentSpotlight === 'vaishnodevi' && (
            <VaishnodeviSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              vaishnodeviItem={vaishnodeviItem}
            />
          )}

          {currentSpotlight === 'mandira' && (
            <MandiraDamSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              mandiraItem={mandiraDamItem}
            />
          )}

          {currentSpotlight === 'igpark' && (
            <IgParkSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              igParkItem={igParkItem}
            />
          )}

          {currentSpotlight === 'pitamahal' && (
            <PitamahalSpotlight
              onSelectItem={onSelectItem}
              onLocateOnMap={onLocateOnMap}
              pitamahalItem={pitamahalItem}
            />
          )}
        </div>
      )}

      {/* Results Header */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-base sm:text-lg font-bold text-slate-900">
          Showing {filteredItems.length} {filteredItems.length === 1 ? 'Listing' : 'Listings'}
          {selectedLocality !== 'All Localities' && ` in ${selectedLocality}`}
        </h3>
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="text-xs text-sky-600 hover:text-sky-800 font-semibold"
          >
            Clear Search Filter
          </button>
        )}
      </div>

      {/* Directory Grid */}
      {filteredItems.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-xl hover:border-sky-300 transition-all flex flex-col justify-between"
            >
              <div>
                {/* Image or Hero Banner */}
                {item.imageUrl && (
                  <div className="relative h-44 overflow-hidden bg-slate-100">
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                    <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                      <span className="bg-white/90 backdrop-blur-md text-slate-800 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider shadow-xs">
                        {item.subcategory}
                      </span>
                      {item.priceRange && (
                        <span className="bg-slate-900/80 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                          {item.priceRange}
                        </span>
                      )}
                    </div>

                    {item.verified && (
                      <div className="absolute top-3 right-3 bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Verified</span>
                      </div>
                    )}

                    {item.emergencyAvailable && (
                      <div className="absolute bottom-3 left-3 bg-rose-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                        <span>24/7 Emergency</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Card Body */}
                <div className="p-5">
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <h4 className="font-bold text-slate-900 text-base group-hover:text-sky-600 transition-colors leading-tight">
                      {item.name}
                    </h4>
                  </div>

                  {/* Rating & Reviews */}
                  {item.rating && (
                    <div className="flex items-center gap-1.5 text-xs text-slate-600 mb-2.5">
                      <div className="flex items-center text-amber-500">
                        <Star className="w-3.5 h-3.5 fill-amber-400" />
                        <span className="font-bold ml-1 text-slate-800">{item.rating}</span>
                      </div>
                      {item.reviewsCount && (
                        <span className="text-slate-400">
                          ({item.reviewsCount.toLocaleString()} reviews)
                        </span>
                      )}
                    </div>
                  )}

                  {/* Locality & Address */}
                  <div className="flex items-start gap-1.5 text-xs text-slate-500 mb-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    <span className="line-clamp-1">{item.locality} • {item.address}</span>
                  </div>

                  {/* Description preview */}
                  <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-3">
                    {item.description}
                  </p>

                  {/* Key Highlights / Badges */}
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    {item.highlights.slice(0, 2).map((h, i) => (
                      <span
                        key={i}
                        className="text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-medium"
                      >
                        {h}
                      </span>
                    ))}
                    {item.affiliation && (
                      <span className="text-[11px] bg-sky-50 text-sky-800 px-2 py-0.5 rounded-md font-medium">
                        {item.affiliation}
                      </span>
                    )}
                  </div>

                  {/* Operational Hours */}
                  {item.timing && (
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span className="line-clamp-1">{item.timing}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="px-5 pb-5 pt-3 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  {item.phone && (
                    <a
                      href={`tel:${cleanPhoneForDialing(item.phone)}`}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold transition-colors"
                      title="Direct Call"
                    >
                      <Phone className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="hidden sm:inline">Call</span>
                    </a>
                  )}

                  <button
                    onClick={() => onLocateOnMap(item)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 text-xs font-semibold transition-colors"
                    title="Show on map"
                  >
                    <Navigation className="w-3.5 h-3.5 text-sky-600" />
                    <span>Locate</span>
                  </button>
                </div>

                <button
                  onClick={() => onSelectItem(item)}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors shadow-2xs"
                >
                  View Details →
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-lg mx-auto">
          <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-3" />
          <h4 className="text-lg font-bold text-slate-900 mb-1">No Listings Found</h4>
          <p className="text-xs text-slate-500 mb-4">
            We couldn't find any listings matching your current search query or filter combination.
          </p>
          <div className="flex justify-center gap-2">
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setSelectedLocality('All Localities');
                setDietaryFilter('');
                setVerifiedOnly(false);
              }}
              className="px-4 py-2 rounded-xl bg-sky-600 text-white text-xs font-semibold hover:bg-sky-700 transition-colors"
            >
              Reset All Filters
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
