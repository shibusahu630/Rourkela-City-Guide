import React from 'react';
import { EMERGENCY_CONTACTS } from '../data/rourkelaData';
import { 
  X, 
  PhoneCall, 
  AlertTriangle, 
  ShieldAlert, 
  HeartPulse, 
  Flame, 
  Shield, 
  Users, 
  Phone, 
  CheckCircle2,
  Droplets
} from 'lucide-react';
import { cleanPhoneForDialing } from '../utils/directoryUtils';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const categoryIcons: Record<string, any> = {
    Administration: ShieldAlert,
    Medical: HeartPulse,
    Police: Shield,
    Fire: Flame,
    Helpline: Users,
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="relative bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-rose-200 animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col"
        role="dialog"
        aria-labelledby="emergency-modal-title"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-700 via-red-600 to-rose-800 text-white p-6 shrink-0 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors"
            aria-label="Close emergency modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold mb-2">
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Rourkela Emergency & Public Health Helplines</span>
          </div>

          <h3 id="emergency-modal-title" className="text-2xl font-extrabold tracking-tight font-display">
            Emergency Contacts & 24/7 Hotlines
          </h3>
          <p className="text-xs text-rose-100 mt-1 max-w-lg">
            Direct verified phone numbers for emergency casualty, trauma units, police, fire, ambulance, and disaster response.
          </p>
        </div>

        {/* Emergency Disclaimer mandated by prompt section 5 */}
        <div className="p-4 bg-amber-50 border-b border-amber-200 flex items-start gap-3 shrink-0">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-900 leading-relaxed">
            <strong className="font-bold block mb-0.5 text-amber-950">
              Official Emergency Verification Disclaimer:
            </strong>
            Do not assume every medical facility has a 24-hour trauma ward simply because its general premises are accessible. The primary certified 24/7 trauma and casualty departments in Rourkela are <strong>Ispat General Hospital (IGH) Sector 19 Casualty</strong>, <strong>Rourkela Govt Hospital (RGH) Panposh Road</strong>, <strong>Apollo Super Speciality Sector 19</strong>, and <strong>JP Hospital & Research Centre NH-143 Dandiapali</strong>. Always call the emergency helpline before transit during critical medical situations.
          </div>
        </div>

        {/* Featured 24/7 Tertiary Emergency & Blood Bank Banners */}
        <div className="mx-6 mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 shrink-0">
          <div className="p-3 rounded-2xl bg-blue-50 border border-blue-200 flex flex-col items-start gap-2.5 shadow-2xs">
            <div className="w-full h-20 rounded-xl overflow-hidden shrink-0 border border-blue-200 shadow-2xs bg-slate-900">
              <img
                src="/assets/aistudio/RGH_1618768712_38ccb2f3.webp"
                alt="Rourkela Government Hospital (RGH), Panposh Road"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="w-full min-w-0">
              <div className="flex items-center gap-1 text-blue-700 text-[10px] font-bold uppercase tracking-wider mb-0.5">
                <HeartPulse className="w-3 h-3 text-blue-600" />
                <span>24/7 Govt Casualty & 108</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs truncate">
                Rourkela Govt Hospital (RGH)
              </h4>
              <p className="text-[11px] text-slate-600 truncate">
                Panposh Road • BSKY & MCH
              </p>
              <div className="mt-2 w-full grid grid-cols-2 gap-1.5">
                <a
                  href="tel:06612400108"
                  className="inline-flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg bg-blue-700 hover:bg-blue-800 text-white font-bold text-[10px] transition-colors"
                >
                  <Phone className="w-3 h-3" />
                  <span>2400108</span>
                </a>
                <a
                  href="tel:108"
                  className="inline-flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] transition-colors"
                >
                  <PhoneCall className="w-3 h-3" />
                  <span>Call 108</span>
                </a>
              </div>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-sky-50 border border-sky-200 flex flex-col items-start gap-2.5 shadow-2xs">
            <div className="w-full h-20 rounded-xl overflow-hidden shrink-0 border border-sky-200 shadow-2xs bg-slate-900">
              <img
                src="/assets/aistudio/apollo_8216d922.jpg"
                alt="Apollo Super Speciality Hospital, Sector 19"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="w-full min-w-0">
              <div className="flex items-center gap-1 text-sky-700 text-[10px] font-bold uppercase tracking-wider mb-0.5">
                <HeartPulse className="w-3 h-3 text-sky-600" />
                <span>24/7 Tertiary Emergency</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs truncate">
                Apollo Super Speciality
              </h4>
              <p className="text-[11px] text-slate-600 truncate">
                Sector 19 • Cath Lab & ICU
              </p>
              <a
                href="tel:06617101108"
                className="mt-2 w-full inline-flex items-center justify-center gap-1 px-2.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold text-[11px] transition-colors"
              >
                <Phone className="w-3 h-3" />
                <span>0661-7101108</span>
              </a>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-teal-50 border border-teal-200 flex flex-col items-start gap-2.5 shadow-2xs">
            <div className="w-full h-20 rounded-xl overflow-hidden shrink-0 border border-teal-200 shadow-2xs bg-slate-900">
              <img
                src="/assets/aistudio/JP_a2a10ef8.jpg"
                alt="JP Hospital & Research Centre, NH-143"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="w-full min-w-0">
              <div className="flex items-center gap-1 text-teal-700 text-[10px] font-bold uppercase tracking-wider mb-0.5">
                <HeartPulse className="w-3 h-3 text-teal-600" />
                <span>24/7 Polytrauma Casualty</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs truncate">
                JP Hospital & Research
              </h4>
              <p className="text-[11px] text-slate-600 truncate">
                NH-143 • Trauma, NICU, Dialysis
              </p>
              <a
                href="tel:06612464111"
                className="mt-2 w-full inline-flex items-center justify-center gap-1 px-2.5 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold text-[11px] transition-colors"
              >
                <Phone className="w-3 h-3" />
                <span>0661-2464111</span>
              </a>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 flex flex-col items-start gap-2.5 shadow-2xs">
            <div className="w-full h-20 rounded-xl overflow-hidden shrink-0 border border-rose-200 shadow-2xs bg-slate-900">
              <img
                src="/assets/aistudio/blood_bank_4714262c.webp"
                alt="Rourkela Red Cross & IGH Blood Bank, Sector 19"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="w-full min-w-0">
              <div className="flex items-center gap-1 text-rose-700 text-[10px] font-bold uppercase tracking-wider mb-0.5">
                <Droplets className="w-3 h-3 text-rose-600 fill-rose-600" />
                <span>Certified 24/7 Blood Centre</span>
              </div>
              <h4 className="font-bold text-slate-900 text-xs truncate">
                Red Cross & IGH Blood Bank
              </h4>
              <p className="text-[11px] text-slate-600 truncate">
                Sector 19 • PRBC & Platelets
              </p>
              <a
                href="tel:06612642444"
                className="mt-2 w-full inline-flex items-center justify-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] transition-colors"
              >
                <Phone className="w-3 h-3" />
                <span>0661-2642444</span>
              </a>
            </div>
          </div>
        </div>

        {/* Contacts list */}
        <div className="overflow-y-auto p-6 space-y-4">
          <div className="grid grid-cols-1 gap-3">
            {EMERGENCY_CONTACTS.map((item, index) => {
              const Icon = categoryIcons[item.category] || PhoneCall;
              const isCritical = item.category === 'Medical' || item.category === 'Administration';

              return (
                <div
                  key={index}
                  className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isCritical
                      ? 'bg-rose-50/50 border-rose-200 hover:border-rose-300'
                      : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isCritical ? 'bg-rose-600 text-white' : 'bg-slate-800 text-white'
                    }`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-slate-900 text-sm">
                          {item.service}
                        </h4>
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-white text-slate-700 border border-slate-200">
                          {item.available}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{item.address}</p>
                      <p className="text-xs text-slate-600 mt-1">{item.notes}</p>
                    </div>
                  </div>

                  {/* Actions / Direct Dial Buttons */}
                  <div className="flex items-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200">
                    <a
                      href={`tel:${cleanPhoneForDialing(item.phone)}`}
                      className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all ${
                        isCritical
                          ? 'bg-rose-600 hover:bg-rose-700 text-white'
                          : 'bg-slate-900 hover:bg-slate-800 text-white'
                      }`}
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>{item.phone}</span>
                    </a>

                    {item.altPhone && (
                      <a
                        href={`tel:${cleanPhoneForDialing(item.altPhone)}`}
                        className="px-3 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 transition-colors"
                        title="Alternate number"
                      >
                        {item.altPhone}
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-semibold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Updated with Sundargarh District Administration verified directories</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
          >
            Close Emergency Panel
          </button>
        </div>
      </div>
    </div>
  );
};
