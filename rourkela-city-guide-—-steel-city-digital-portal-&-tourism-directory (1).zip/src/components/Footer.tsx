import React from 'react';
import { 
  Building2, 
  ShieldCheck, 
  PhoneCall, 
  ExternalLink, 
  Heart, 
  MapPin, 
  Compass 
} from 'lucide-react';

interface FooterProps {
  onOpenEmergency: () => void;
  onOpenSubmit: () => void;
  onSelectTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenEmergency,
  onOpenSubmit,
  onSelectTab
}) => {
  const officialLinks = [
    { name: 'Odisha Tourism Official', url: 'https://odishatourism.gov.in' },
    { name: 'Rourkela Municipal Corporation', url: 'https://rmc.nic.in' },
    { name: 'SAIL Rourkela Steel Plant', url: 'https://sail.co.in/en/plants/rourkela-steel-plant' },
    { name: 'NIT Rourkela Campus Portal', url: 'https://www.nitrkl.ac.in' },
    { name: 'BPUT University Odisha', url: 'https://www.bput.ac.in' },
    { name: 'Indian Railways Rail Enquiry', url: 'https://indianrail.gov.in' },
    { name: 'Airports Authority of India (AAI)', url: 'https://www.aai.aero' },
    { name: 'Sundargarh District Portal', url: 'https://sundargarh.nic.in' }
  ];

  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-800 pt-16 pb-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 to-indigo-600 flex items-center justify-center text-white font-extrabold text-xl shadow-lg">
                R
              </div>
              <div>
                <span className="font-extrabold text-white text-lg tracking-tight font-display">
                  ROURKELA CITY GUIDE
                </span>
                <p className="text-[11px] text-sky-400 font-medium">The Steel City of Odisha</p>
              </div>
            </div>

            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              An independent, Google-standard digital city guide and verified directory built for residents, students, professionals, travelers, and businesses in Rourkela, Sundargarh, Odisha.
            </p>

            <div className="flex items-center gap-2 text-[11px] text-emerald-400 font-medium">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>Independent Civic Portal • Verified Coordinates & Phone Numbers</span>
            </div>
          </div>

          {/* Quick Directory Sections */}
          <div>
            <h4 className="text-white font-bold text-sm mb-3 font-display">Explore Directory</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onSelectTab('attractions')} className="hover:text-white transition-colors">
                  Tourist Landmarks & Parks
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('map')} className="hover:text-white transition-colors">
                  Interactive City Map
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('education')} className="hover:text-white transition-colors">
                  Schools & NIT Rourkela
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('health')} className="hover:text-white transition-colors">
                  Hospitals & 24/7 ER
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('dining')} className="hover:text-white transition-colors">
                  Restaurants & Odia Cuisine
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('hotels')} className="hover:text-white transition-colors">
                  Hotels & Accommodations
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('transport')} className="hover:text-white transition-colors">
                  Junction & Transit Guide
                </button>
              </li>
            </ul>
          </div>

          {/* Official Government & Partner Portals */}
          <div>
            <h4 className="text-white font-bold text-sm mb-3 font-display">Official Sources</h4>
            <ul className="space-y-2">
              {officialLinks.slice(0, 5).map((link, idx) => (
                <li key={idx}>
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-white flex items-center gap-1 transition-colors"
                  >
                    <span>{link.name}</span>
                    <ExternalLink className="w-3 h-3 text-slate-600" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Citizen Actions & SOS */}
          <div>
            <h4 className="text-white font-bold text-sm mb-3 font-display">Citizen Services</h4>
            <div className="space-y-3">
              <button
                onClick={onOpenEmergency}
                className="w-full py-2.5 px-3 rounded-xl bg-rose-600/90 hover:bg-rose-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Emergency 24/7 Hotlines</span>
              </button>

              <button
                onClick={onOpenSubmit}
                className="w-full py-2.5 px-3 rounded-xl border border-slate-700 hover:border-slate-500 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>List Business / Suggest Edit</span>
              </button>

              <p className="text-[11px] text-slate-500 pt-2 leading-tight">
                Help keep Rourkela's directory accurate by submitting newly opened businesses or reported edits.
              </p>
            </div>
          </div>
        </div>

        {/* Legal Disclaimer Mandated in Prompt */}
        <div className="pt-8 border-t border-slate-900 text-slate-400 text-[11px] leading-relaxed space-y-2">
          <p>
            <strong>Disclaimer:</strong> This website is an independent community city guide. All business names, logos, school affiliations, and institutional details remain trademarks or registered properties of their respective organizations. While directory listings are meticulously verified against official gazettes, university circulars, and departmental announcements, school admissions, hospital emergency services, flight operations, and restaurant opening hours are subject to change. Visitors are advised to cross-verify directly with institutions before traveling.
          </p>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-4 gap-2 text-slate-400">
            <div>
              © {new Date().getFullYear()} Rourkela City Guide — Dedicated to the Steel City of Odisha.
            </div>
            <div className="flex items-center gap-4">
              <span>Privacy Policy</span>
              <span>•</span>
              <span>Terms of Directory</span>
              <span>•</span>
              <span>Sundargarh, Odisha</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
