import React from 'react';
import { 
  Sparkles, 
  MapPin, 
  Clock, 
  Navigation, 
  CheckCircle2, 
  Info, 
  Compass, 
  Phone 
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';

interface HanumanVatikaSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  hanumanVatikaItem?: DirectoryItem;
}

export const HanumanVatikaSpotlight: React.FC<HanumanVatikaSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  hanumanVatikaItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-amber-500/10 via-orange-500/5 to-slate-900/5 rounded-3xl p-6 sm:p-8 border border-amber-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-2/5 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[3/4] sm:aspect-[4/3] lg:aspect-[3/4] max-h-[420px] bg-slate-900 group">
            <img
              src="/assets/aistudio/hanuman_vatika_999f74d3.jpg"
              alt="Hanuman Vatika 75-foot monumental statue, Rourkela"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-black/20 pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-amber-900 flex items-center gap-1.5 shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Signature Landmark of Rourkela</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-amber-300 font-semibold uppercase tracking-wider">
                75-Foot Monumental Statue
              </p>
              <h4 className="text-lg font-bold">Hanuman Vatika Temple Complex</h4>
              <p className="text-xs text-slate-300">Civil Township, Rourkela, Odisha</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Featured Tourist & Spiritual Destination</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Hanuman Vatika: Towering Faith & Landscaped Serenity
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Spanning over <strong>13 landscaped acres</strong> in the heart of Civil Township, Hanuman Vatika is Rourkela's most iconic religious attraction. Renowned across India for its majestic <strong>75-foot statue of Lord Hanuman</strong> sculpted by Sri Laxman Swami of Hyderabad, the garden complex also preserves replica shrines of Odisha's sacred heritage: Puri Jagannath Temple, Bata Mangala, Vaishno Devi, Sarala, and the 12 Jyotirlingas.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Suggested Visit Duration</span>
              <strong className="text-slate-800 text-sm">1 – 2 Hours</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Visiting Hours</span>
              <strong className="text-slate-800 text-sm">06:00 AM – 09:00 PM (Daily)</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Entry Fee</span>
              <strong className="text-emerald-700 text-sm">Free Public Entry</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Key Highlights</span>
              <strong className="text-slate-800">13 Shrines, Kalyan Mandap, Gardens</strong>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <a
              href="https://www.google.com/maps/dir/?api=1&destination=22.2312,84.8362"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-colors"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Get Directions to Hanuman Vatika ↗</span>
            </a>

            {hanumanVatikaItem && (
              <>
                <button
                  onClick={() => onLocateOnMap(hanumanVatikaItem)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-white text-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <MapPin className="w-3.5 h-3.5 text-sky-600" />
                  <span>Locate on Interactive Map</span>
                </button>

                <button
                  onClick={() => onSelectItem(hanumanVatikaItem)}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
                >
                  <span>Full Profile & Details →</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
