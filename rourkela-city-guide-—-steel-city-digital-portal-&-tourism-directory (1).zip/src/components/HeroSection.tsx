import React from 'react';
import { 
  Search, 
  MapPin, 
  Sparkles, 
  Compass, 
  GraduationCap, 
  HeartPulse, 
  UtensilsCrossed, 
  BedDouble, 
  Train, 
  ShoppingBag, 
  Factory, 
  ShieldCheck, 
  ChevronRight, 
  PhoneCall 
} from 'lucide-react';

interface HeroSectionProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onSelectCategory: (category: string) => void;
  onOpenMap: () => void;
  onOpenEmergency: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  searchQuery,
  setSearchQuery,
  onSelectCategory,
  onOpenMap,
  onOpenEmergency
}) => {
  const quickSearchPrompts = [
    'Ispat General Hospital (IGH)',
    'Red Cross & IGH Blood Bank',
    'Birsa Munda Hockey Stadium',
    'NIT Rourkela',
    'Hanuman Vatika',
    'RIMS Rourkela',
    'Chandan\'s Fine Dining',
    'Rourkela Junction Vande Bharat',
    'Delhi Public School',
    'Vedvyas Temple',
    'MAYFAIR Rourkela',
  ];

  const categoryCards = [
    { id: 'attractions', name: 'Tourist Places', icon: Compass, color: 'from-amber-500 to-orange-600', count: '10+ Spots', desc: 'Hanuman Vatika, Vedvyas, Hockey Stadium' },
    { id: 'education', name: 'Education', icon: GraduationCap, color: 'from-blue-600 to-cyan-700', count: 'Schools & Colleges', desc: 'NIT Rourkela, BPUT, DPS, KV, ICSE' },
    { id: 'health', name: 'Hospitals & ER', icon: HeartPulse, color: 'from-rose-500 to-red-600', count: 'Emergency Care', desc: 'IGH Sector 19, Apollo, RGH, 24/7 Casualty' },
    { id: 'dining', name: 'Food & Dining', icon: UtensilsCrossed, color: 'from-emerald-500 to-teal-700', count: 'Cuisines & Sweets', desc: 'Chhena Poda, Odia Thali, Biryani, Cafes' },
    { id: 'hotels', name: 'Hotels & Stay', icon: BedDouble, color: 'from-purple-600 to-indigo-700', count: 'Verified Stays', desc: 'MAYFAIR Resort, Radhika Regency, Central Park' },
    { id: 'transport', name: 'Railway & Transit', icon: Train, color: 'from-sky-600 to-blue-800', count: 'Junction & Flights', desc: 'ROU Junction, Airport RRK, Mo Bus routes' },
    { id: 'shopping', name: 'Markets & Malls', icon: ShoppingBag, color: 'from-pink-500 to-rose-600', count: 'Daily Markets', desc: 'Forum Galleria, Ambagan, Bisra Road' },
    { id: 'business', name: 'Jobs & Industry', icon: Factory, color: 'from-slate-700 to-zinc-800', count: 'SAIL & MSME', desc: 'RSP careers, Kalunga cluster, NIT TIIR' },
  ];

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 text-white pt-12 pb-20 px-4 sm:px-6 lg:px-8">
      {/* Background ambient pattern */}
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-sky-500/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-5xl mx-auto text-center">
        {/* City badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800/90 border border-slate-700 text-sky-300 text-xs font-semibold mb-6 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Steel City of Odisha • Smart Urban Agglomeration</span>
          <span className="hidden sm:inline text-slate-500">|</span>
          <span className="hidden sm:inline text-slate-300">Population ~550,000+ (Census)</span>
        </div>

        {/* Main Title */}
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white mb-4 font-display">
          Rourkela City
          <span className="block text-2xl sm:text-3xl md:text-4xl font-normal text-sky-400 mt-2">
            Discover • Explore • Connect
          </span>
        </h1>

        <p className="text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto font-light leading-relaxed mb-8">
          Your City. Everything in One Place. Find verified schools, colleges, hospitals, dining, tourist landmarks, hotels, transit, and local services.
        </p>

        {/* Search Bar */}
        <div className="max-w-3xl mx-auto mb-6">
          <div className="relative flex items-center bg-white rounded-2xl shadow-2xl p-2 border border-slate-200 text-slate-900 focus-within:ring-4 focus-within:ring-sky-500/30 transition-all">
            <Search className="w-6 h-6 text-slate-400 ml-3 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search schools, hospitals, restaurants, attractions, transit..."
              className="w-full px-4 py-3 text-base text-slate-800 placeholder-slate-400 focus:outline-none"
              aria-label="Search city directory"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-slate-400 hover:text-slate-600 px-2 py-1 mr-2"
              >
                Clear
              </button>
            )}
            <button
              onClick={() => onSelectCategory('all')}
              className="bg-sky-600 hover:bg-sky-700 text-white font-bold px-6 py-3 rounded-xl text-sm transition-colors shrink-0 shadow-md flex items-center gap-2"
            >
              <span>Explore</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Search suggestions chips */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10 max-w-3xl mx-auto">
          <span className="text-xs text-slate-400 font-medium">Quick search:</span>
          {quickSearchPrompts.map((prompt) => (
            <button
              key={prompt}
              onClick={() => {
                setSearchQuery(prompt);
                onSelectCategory('all');
              }}
              className="text-xs px-2.5 py-1 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Primary Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
          <button
            onClick={onOpenMap}
            className="inline-flex items-center gap-2.5 bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white font-bold px-6 py-3.5 rounded-xl shadow-lg shadow-sky-900/40 text-sm transition-all hover:-translate-y-0.5"
          >
            <MapPin className="w-5 h-5 text-sky-200" />
            <span>Launch Interactive City Map</span>
          </button>

          <button
            onClick={onOpenEmergency}
            className="inline-flex items-center gap-2 bg-rose-950/80 hover:bg-rose-900/90 text-rose-200 border border-rose-700/60 font-semibold px-5 py-3.5 rounded-xl text-sm transition-all"
          >
            <PhoneCall className="w-4 h-4 text-rose-400" />
            <span>Emergency Services & IGH Helpline</span>
          </button>
        </div>

        {/* Quick Category Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left">
          {categoryCards.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className="group relative p-4 rounded-xl bg-slate-800/70 hover:bg-slate-800 border border-slate-700/70 hover:border-sky-500/50 transition-all hover:shadow-lg text-left"
              >
                <div className={`w-9 h-9 rounded-lg bg-gradient-to-tr ${cat.color} flex items-center justify-center text-white mb-2.5 shadow-sm group-hover:scale-110 transition-transform`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex justify-between items-baseline">
                  <h3 className="text-sm font-bold text-white group-hover:text-sky-300 transition-colors">
                    {cat.name}
                  </h3>
                  <span className="text-[10px] text-sky-400 font-medium">
                    {cat.count}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1 line-clamp-1 font-light">
                  {cat.desc}
                </p>
              </button>
            );
          })}
        </div>

        {/* Trust & Source Notice */}
        <div className="mt-12 pt-6 border-t border-slate-800/80 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Verified against Odisha Tourism, SAIL & Academic Registries</span>
          </div>
          <div className="hidden sm:inline">•</div>
          <div>All Coordinates Checked for Navigation Accuracy</div>
          <div className="hidden sm:inline">•</div>
          <div>Emergency Departments Clearly Distinguished</div>
        </div>
      </div>
    </div>
  );
};
