import React from 'react';
import { 
  MapPin, 
  Clock, 
  Navigation, 
  CheckCircle2, 
  Sparkles, 
  Phone,
  Trees,
  Waves,
  Eye,
  TrainTrack,
  Music,
  Fish
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';

interface IgParkSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  igParkItem?: DirectoryItem;
}

export const IgParkSpotlight: React.FC<IgParkSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  igParkItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-emerald-950/10 via-teal-900/5 to-amber-950/5 rounded-3xl p-6 sm:p-8 border border-emerald-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[4/3] bg-slate-900 group">
            <img
              src="/assets/aistudio/Indira-Gandhi-Park-Rourkela-Sundargarh_dfe9074a.webp"
              alt="Indira Gandhi Park boating lake with artistic decorative boat sculpture surrounded by lush tropical greenery"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-emerald-950 flex items-center gap-1.5 shadow-sm">
              <Trees className="w-3.5 h-3.5 text-emerald-600" />
              <span>Sector 2 • 42-Acre Botanical Sanctuary</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-emerald-300 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>Boating Lake & Dancing Musical Fountain</span>
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Indira Gandhi Park & Musical Fountain</h4>
              <p className="text-xs text-slate-300">Sector 2, Steel Township, Rourkela, Odisha 769006</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-700" />
            <span>SAIL RSP Botanical Sanctuary & Family Leisure Hub</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Indira Gandhi Park & Musical Fountain
          </h3>

          <p className="text-sm text-slate-600 leading-relaxed">
            Spanning over 42 acres in Sector 2, Indira Gandhi Park is the green lungs of Rourkela, beautifully maintained by SAIL RSP. Visitors can stroll along the serene boating lake featuring artistic floating sculptures, enjoy the evening musical fountain synchronized with lights and melody, take a ride on the children’s toy train, explore the deer park and aviary, and ascend the observation tower for sweeping steel city panoramas.
          </p>

          {/* Feature Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-teal-700 text-xs font-bold mb-0.5">
                <Waves className="w-3.5 h-3.5 text-teal-600" />
                <span>Boating Lake</span>
              </div>
              <p className="text-[11px] text-slate-500">Sculpted Boat & Calming Waters</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-rose-700 text-xs font-bold mb-0.5">
                <Music className="w-3.5 h-3.5 text-rose-600" />
                <span>Musical Fountain</span>
              </div>
              <p className="text-[11px] text-slate-500">6:30 PM Dancing Light Show</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-amber-700 text-xs font-bold mb-0.5">
                <TrainTrack className="w-3.5 h-3.5 text-amber-600" />
                <span>Toy Train</span>
              </div>
              <p className="text-[11px] text-slate-500">Children's Garden Railway</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold mb-0.5">
                <Trees className="w-3.5 h-3.5 text-emerald-600" />
                <span>Mini Zoo & Deer</span>
              </div>
              <p className="text-[11px] text-slate-500">Spotted Deer & Aviary</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-sky-700 text-xs font-bold mb-0.5">
                <Eye className="w-3.5 h-3.5 text-sky-600" />
                <span>Watchtower</span>
              </div>
              <p className="text-[11px] text-slate-500">360° Steel Township View</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-indigo-700 text-xs font-bold mb-0.5">
                <Clock className="w-3.5 h-3.5 text-indigo-600" />
                <span>Park Hours</span>
              </div>
              <p className="text-[11px] text-slate-500">5:30 AM – 8:30 PM (₹20)</p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap gap-3">
            <a
              href="tel:06612646200"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-xs sm:text-sm shadow-sm transition-all"
            >
              <Phone className="w-4 h-4" />
              <span>Inquiry (0661-2646200)</span>
            </a>

            {igParkItem && (
              <>
                <button
                  onClick={() => onLocateOnMap(igParkItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-xs sm:text-sm border border-slate-300 shadow-2xs transition-all"
                >
                  <MapPin className="w-4 h-4 text-emerald-600" />
                  <span>Locate on Map</span>
                </button>

                <button
                  onClick={() => onSelectItem(igParkItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-semibold text-xs sm:text-sm border border-emerald-300 shadow-2xs transition-all"
                >
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>View Details & Shows</span>
                </button>
              </>
            )}

            <a
              href="https://maps.google.com/?q=22.2590,84.8680"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs sm:text-sm border border-slate-300 shadow-2xs transition-all"
            >
              <Navigation className="w-4 h-4 text-sky-600" />
              <span>Directions</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
