import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { 
  DirectoryItem, 
  CategoryType, 
  LocalityType 
} from '../types/directory';
import { 
  Layers, 
  Navigation, 
  ExternalLink, 
  Compass, 
  GraduationCap, 
  HeartPulse, 
  UtensilsCrossed, 
  BedDouble, 
  Train, 
  ShoppingBag, 
  Factory, 
  Phone, 
  CheckCircle2, 
  Search,
  Maximize2
} from 'lucide-react';

interface InteractiveMapProps {
  items: DirectoryItem[];
  selectedItem: DirectoryItem | null;
  onSelectItem: (item: DirectoryItem) => void;
  onCloseDetailModal?: () => void;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  items,
  selectedItem,
  onSelectItem,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [id: string]: L.Marker }>({});
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  const [activeCategory, setActiveCategory] = useState<CategoryType>('all');
  const [selectedLocality, setSelectedLocality] = useState<LocalityType | 'All Localities'>('All Localities');
  const [mapSearch, setMapSearch] = useState('');
  const [currentBaseMap, setCurrentBaseMap] = useState<'standard' | 'humanitarian' | 'terrain'>('standard');
  const [activeMarkerItem, setActiveMarkerItem] = useState<DirectoryItem | null>(selectedItem);

  // Category styles: color & icon label
  const categoryMeta: Record<string, { label: string; color: string; bgClass: string; icon: any }> = {
    all: { label: 'All Places', color: '#0284c7', bgClass: 'bg-sky-600', icon: Layers },
    attractions: { label: 'Tourism & Parks', color: '#059669', bgClass: 'bg-emerald-600', icon: Compass },
    schools: { label: 'Schools', color: '#2563eb', bgClass: 'bg-blue-600', icon: GraduationCap },
    colleges: { label: 'Colleges & NIT', color: '#4f46e5', bgClass: 'bg-indigo-600', icon: GraduationCap },
    hospitals: { label: 'Hospitals & ER', color: '#dc2626', bgClass: 'bg-rose-600', icon: HeartPulse },
    restaurants: { label: 'Restaurants & Food', color: '#d97706', bgClass: 'bg-amber-600', icon: UtensilsCrossed },
    hotels: { label: 'Hotels & Stay', color: '#7c3aed', bgClass: 'bg-purple-600', icon: BedDouble },
    transport: { label: 'Railway & Transit', color: '#0891b2', bgClass: 'bg-cyan-600', icon: Train },
    shopping: { label: 'Markets & Malls', color: '#db2777', bgClass: 'bg-pink-600', icon: ShoppingBag },
    industry: { label: 'SAIL & Industry', color: '#475569', bgClass: 'bg-slate-600', icon: Factory },
  };

  // Helper to create custom HTML pin markers
  const createCustomPinIcon = (category: CategoryType, isSelected: boolean) => {
    const meta = categoryMeta[category] || categoryMeta.all;
    const color = meta.color;
    const size = isSelected ? 42 : 32;

    const svgHtml = `
      <div style="position: relative; width: ${size}px; height: ${size}px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: transform 0.2s;">
        <svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="${color}" stroke="#ffffff" stroke-width="1.5" style="filter: drop-shadow(0 4px 6px rgba(0,0,0,0.35));">
          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/>
          <circle cx="12" cy="9" r="3" fill="#ffffff" />
        </svg>
        ${isSelected ? `<div style="position: absolute; top: -6px; right: -6px; width: 12px; height: 12px; border-radius: 9999px; background: #22c55e; border: 2px solid #ffffff;"></div>` : ''}
      </div>
    `;

    return L.divIcon({
      className: 'custom-leaflet-marker',
      html: svgHtml,
      iconSize: [size, size],
      iconAnchor: [size / 2, size],
      popupAnchor: [0, -size],
    });
  };

  // Filter items for map
  const filteredMapItems = items.filter((item) => {
    if (activeCategory !== 'all') {
      if (activeCategory === 'schools' || activeCategory === 'colleges') {
        if (item.category !== activeCategory) return false;
      } else if (item.category !== activeCategory) {
        return false;
      }
    }
    if (selectedLocality !== 'All Localities' && item.locality !== selectedLocality) {
      return false;
    }
    if (mapSearch.trim()) {
      const q = mapSearch.toLowerCase();
      const match =
        item.name.toLowerCase().includes(q) ||
        item.subcategory.toLowerCase().includes(q) ||
        item.address.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  // Base map tile URLs
  const baseMapTiles = {
    standard: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    humanitarian: 'https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png',
    terrain: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
  };

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    // Rourkela geographic center
    const rourkelaCenter: [number, number] = [22.2500, 84.8536];

    const map = L.map(mapContainerRef.current, {
      center: rourkelaCenter,
      zoom: 13,
      zoomControl: true,
      scrollWheelZoom: true,
    });

    const tileLayer = L.tileLayer(baseMapTiles[currentBaseMap], {
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors',
      maxZoom: 19,
    }).addTo(map);

    tileLayerRef.current = tileLayer;
    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update base map layer
  useEffect(() => {
    if (!mapInstanceRef.current || !tileLayerRef.current) return;
    mapInstanceRef.current.removeLayer(tileLayerRef.current);
    const newLayer = L.tileLayer(baseMapTiles[currentBaseMap], {
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors',
      maxZoom: 19,
    }).addTo(mapInstanceRef.current);
    tileLayerRef.current = newLayer;
  }, [currentBaseMap]);

  // Update Markers
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear existing markers
    Object.values(markersRef.current).forEach((marker) => marker.remove());
    markersRef.current = {};

    // Add filtered markers
    filteredMapItems.forEach((item) => {
      const isSelected = selectedItem?.id === item.id;
      const icon = createCustomPinIcon(item.category, isSelected);

      const marker = L.marker(item.coordinates, { icon }).addTo(map);

      // Popup Content
      const popupHtml = `
        <div style="font-family: inherit; font-size: 13px; line-height: 1.4; max-width: 260px;">
          <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
            <span style="background: #e0f2fe; color: #0369a1; font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 4px; text-transform: uppercase;">
              ${item.subcategory}
            </span>
            ${item.verified ? '<span style="color: #16a34a; font-size: 11px; font-weight: 600;">✓ Verified</span>' : ''}
          </div>
          <h4 style="font-size: 14px; font-weight: 700; color: #0f172a; margin: 0 0 4px 0;">${item.name}</h4>
          <p style="font-size: 11px; color: #64748b; margin: 0 0 6px 0;">${item.address}</p>
          ${item.phone ? `<p style="font-size: 11px; color: #334155; margin: 0 0 6px 0;"><strong>Phone:</strong> ${item.phone}</p>` : ''}
          ${item.timing ? `<p style="font-size: 11px; color: #334155; margin: 0 0 8px 0;"><strong>Hours:</strong> ${item.timing}</p>` : ''}
          <div style="display: flex; gap: 6px; margin-top: 8px;">
            <a href="https://www.google.com/maps/dir/?api=1&destination=${item.coordinates[0]},${item.coordinates[1]}" target="_blank" rel="noopener noreferrer" style="display: inline-block; background: #0284c7; color: #ffffff; text-decoration: none; padding: 4px 8px; border-radius: 6px; font-weight: 600; font-size: 11px;">
              Get Directions ↗
            </a>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml);

      marker.on('click', () => {
        setActiveMarkerItem(item);
        onSelectItem(item);
      });

      markersRef.current[item.id] = marker;
    });

    // Fit bounds if search or filters active and items exist
    if (filteredMapItems.length > 0 && (mapSearch || activeCategory !== 'all' || selectedLocality !== 'All Localities')) {
      const group = L.featureGroup(Object.values(markersRef.current));
      map.fitBounds(group.getBounds().pad(0.15), { maxZoom: 15 });
    }
  }, [filteredMapItems, selectedItem, activeCategory, selectedLocality, mapSearch]);

  // Handle focusing when a specific item is selected from outside
  useEffect(() => {
    if (selectedItem && mapInstanceRef.current) {
      mapInstanceRef.current.setView(selectedItem.coordinates, 16, { animate: true });
      const marker = markersRef.current[selectedItem.id];
      if (marker) {
        marker.openPopup();
      }
      setActiveMarkerItem(selectedItem);
    }
  }, [selectedItem]);

  const handleResetView = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([22.2500, 84.8536], 13, { animate: true });
      setActiveCategory('all');
      setSelectedLocality('All Localities');
      setMapSearch('');
    }
  };

  return (
    <div className="bg-slate-50 border-t border-b border-slate-200 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-bold mb-2">
              <Navigation className="w-3.5 h-3.5" />
              <span>Interactive Tourism & City Directory Map</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
              Explore Rourkela on the Map
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Accurate verified coordinates for tourist landmarks, hospitals, educational institutions, transit hubs, and dining.
            </p>
          </div>

          {/* Quick Stats & Map controls */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleResetView}
              className="text-xs font-semibold px-3 py-2 rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 flex items-center gap-1.5 shadow-2xs"
            >
              <Maximize2 className="w-3.5 h-3.5 text-slate-500" />
              <span>Reset City Center</span>
            </button>

            {/* Base map selector */}
            <div className="inline-flex rounded-lg border border-slate-300 bg-white p-0.5 shadow-2xs text-xs font-medium">
              <button
                onClick={() => setCurrentBaseMap('standard')}
                className={`px-2.5 py-1.5 rounded-md transition-colors ${currentBaseMap === 'standard' ? 'bg-sky-600 text-white font-bold' : 'text-slate-600 hover:text-slate-900'}`}
              >
                OSM Standard
              </button>
              <button
                onClick={() => setCurrentBaseMap('humanitarian')}
                className={`px-2.5 py-1.5 rounded-md transition-colors ${currentBaseMap === 'humanitarian' ? 'bg-sky-600 text-white font-bold' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Humanitarian
              </button>
              <button
                onClick={() => setCurrentBaseMap('terrain')}
                className={`px-2.5 py-1.5 rounded-md transition-colors ${currentBaseMap === 'terrain' ? 'bg-sky-600 text-white font-bold' : 'text-slate-600 hover:text-slate-900'}`}
              >
                Topographic
              </button>
            </div>
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="bg-white p-3 rounded-2xl shadow-sm border border-slate-200 mb-4 flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between">
          {/* Category Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0 scrollbar-thin">
            {[
              { id: 'all', label: 'All Places' },
              { id: 'attractions', label: 'Attractions' },
              { id: 'hospitals', label: 'Hospitals & ER' },
              { id: 'schools', label: 'Schools' },
              { id: 'colleges', label: 'Colleges / NIT' },
              { id: 'restaurants', label: 'Dining' },
              { id: 'hotels', label: 'Hotels' },
              { id: 'transport', label: 'Transit Hubs' },
              { id: 'shopping', label: 'Shopping' },
              { id: 'industry', label: 'SAIL RSP' },
            ].map((cat) => {
              const isSelected = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id as CategoryType)}
                  className={`text-xs font-semibold px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
                    isSelected
                      ? 'bg-sky-600 text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* Search & Locality Dropdown */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="relative flex-1 sm:w-48">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={mapSearch}
                onChange={(e) => setMapSearch(e.target.value)}
                placeholder="Search pins..."
                className="w-full pl-8 pr-2 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-500/20"
              />
            </div>

            <select
              value={selectedLocality}
              onChange={(e) => setSelectedLocality(e.target.value as any)}
              className="text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-slate-700 font-medium focus:outline-none"
            >
              <option value="All Localities">All Localities</option>
              <option value="Civil Township">Civil Township</option>
              <option value="Uditnagar">Uditnagar</option>
              <option value="Chhend Colony">Chhend Colony</option>
              <option value="Sector 1-20 (Steel Township)">Sector 1-20</option>
              <option value="Panposh">Panposh</option>
              <option value="Birsa Munda / Nayabazar Area">Birsa Munda Area</option>
              <option value="Kalunga">Kalunga</option>
              <option value="Wider Sundargarh">Wider Sundargarh</option>
            </select>
          </div>
        </div>

        {/* Map Canvas and Side Info Card */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Main Leaflet Container */}
          <div className="lg:col-span-3 relative h-[520px] rounded-2xl overflow-hidden border border-slate-200 shadow-md">
            <div ref={mapContainerRef} className="w-full h-full z-10" />

            {/* Float count badge on map */}
            <div className="absolute bottom-4 left-4 z-20 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-200 shadow-md text-xs font-semibold text-slate-700 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Showing {filteredMapItems.length} verified locations</span>
            </div>
          </div>

          {/* Active Location Card / Fast Inspector */}
          <div className="lg:col-span-1 bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex flex-col justify-between">
            {activeMarkerItem ? (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-sky-100 text-sky-800 uppercase tracking-wider">
                    {activeMarkerItem.subcategory}
                  </span>
                  {activeMarkerItem.verified && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Verified
                    </span>
                  )}
                </div>

                {activeMarkerItem.imageUrl && (
                  <div className="h-32 rounded-xl overflow-hidden mb-3 bg-slate-100">
                    <img
                      src={activeMarkerItem.imageUrl}
                      alt={activeMarkerItem.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                <h3 className="font-bold text-slate-900 text-base leading-snug mb-1">
                  {activeMarkerItem.name}
                </h3>
                <p className="text-xs text-slate-500 mb-2">
                  {activeMarkerItem.locality} • {activeMarkerItem.address}
                </p>

                <p className="text-xs text-slate-600 line-clamp-3 mb-3 leading-relaxed">
                  {activeMarkerItem.description}
                </p>

                {activeMarkerItem.phone && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-700 mb-2 font-medium">
                    <Phone className="w-3.5 h-3.5 text-sky-600" />
                    <span>{activeMarkerItem.phone}</span>
                  </div>
                )}

                {activeMarkerItem.timing && (
                  <p className="text-xs text-slate-500 mb-3">
                    <strong className="text-slate-700">Hours:</strong> {activeMarkerItem.timing}
                  </p>
                )}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-4">
                <Navigation className="w-8 h-8 text-slate-300 mb-2 animate-bounce" />
                <h4 className="text-sm font-bold text-slate-700">Click Any Pin on the Map</h4>
                <p className="text-xs text-slate-400 mt-1">
                  View instant details, photos, timings, verified phones, and one-click directions.
                </p>
              </div>
            )}

            {activeMarkerItem && (
              <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
                <a
                  href={`https://www.google.com/maps/dir/?api=1&destination=${activeMarkerItem.coordinates[0]},${activeMarkerItem.coordinates[1]}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Google Maps Directions</span>
                  <ExternalLink className="w-3 h-3" />
                </a>

                <button
                  onClick={() => onSelectItem(activeMarkerItem)}
                  className="w-full py-2 px-3 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold text-xs transition-colors"
                >
                  View Full Directory Profile
                </button>
              </div>
            )}
          </div>
        </div>

        {/* External Map Resource Links as requested in Prompt Section 8 */}
        <div className="mt-4 p-4 rounded-xl bg-white border border-slate-200 text-xs text-slate-600 flex flex-wrap items-center justify-between gap-3">
          <div className="font-semibold text-slate-800">
            Direct Google Maps Curated Views:
          </div>
          <div className="flex flex-wrap gap-2">
            <a
              href="https://www.google.com/maps/search/tourist+places+in+Rourkela"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium inline-flex items-center gap-1"
            >
              Tourist Places ↗
            </a>
            <a
              href="https://www.google.com/maps/search/hospitals+in+Rourkela"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium inline-flex items-center gap-1"
            >
              Hospitals ↗
            </a>
            <a
              href="https://www.google.com/maps/search/restaurants+in+Rourkela"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium inline-flex items-center gap-1"
            >
              Restaurants ↗
            </a>
            <a
              href="https://www.google.com/maps/search/schools+in+Rourkela"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium inline-flex items-center gap-1"
            >
              Schools ↗
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
