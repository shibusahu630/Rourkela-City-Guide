import { 
  Briefcase, 
  Factory, 
  ExternalLink, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles, 
  Rocket, 
  Award, 
  AlertTriangle,
  Navigation 
} from 'lucide-react';

export const JobsAndBusiness: React.FC = () => {
  const officialPortals = [
    {
      title: 'SAIL Rourkela Steel Plant Recruitment',
      agency: 'Steel Authority of India Limited (Maharatna PSU)',
      roles: 'Management Trainees (Technical), OCTT, ACTT, Doctors & Staff Nurses',
      portalUrl: 'https://sailcareers.com',
      notes: 'Official recruitment portal. Always verify roll number and notification PDF directly on sailcareers.com.'
    },
    {
      title: 'SAIL RSP Trade Apprenticeships (ITI & Diploma)',
      agency: 'SAIL RSP Human Resource Development Centre (HRDC)',
      roles: 'Trade Apprentice (Electrician, Fitter, Welder, Machinist), Technician Apprentice',
      portalUrl: 'https://www.apprenticeshipindia.gov.in',
      notes: 'Enrolment through NAPS Apprenticeship portal under Ministry of Skill Development.'
    },
    {
      title: 'NIT Rourkela Faculty & Research Recruitment',
      agency: 'National Institute of Technology Rourkela',
      roles: 'Assistant Professors, JRF / SRF Research Fellows, Technical Officers',
      portalUrl: 'https://www.nitrkl.ac.in/Career',
      notes: 'Premier central academic positions and sponsored DST/DRDO/ISRO research projects.'
    },
    {
      title: 'Startup Odisha & TIIR NIT Rourkela Incubation',
      agency: 'TIIR Centre / Startup Odisha',
      roles: 'Deep-Tech Startup Founders, Incubatee grants up to ₹25 Lakhs, Internships',
      portalUrl: 'https://tiir.nitrkl.ac.in',
      notes: 'Seed funding, mentorship and hardware lab access for entrepreneurs in Western Odisha.'
    }
  ];

  const industrialSectors = [
    {
      title: 'Iron & Steel Core Manufacturing',
      desc: 'Anchor of Western Odisha\'s economy led by 4.5 MTPA SAIL Rourkela Steel Plant with dedicated plate mill for defense warships and aerospace.',
      hiring: 'Metallurgical Engineers, Mechanical maintenance, Blast furnace operators, Quality control'
    },
    {
      title: 'Kalunga Heavy Fabrication & Casting',
      desc: 'Over 200 registered MSME units executing structural fabrication, heavy machinery overhaul, casting foundries, and sponge iron plants.',
      hiring: 'CNC Programmers, ARC Welders, Industrial Draughtsmen, Logistics officers'
    },
    {
      title: 'IT, Automation & Technology Startups',
      desc: 'Emerging tech hub powered by NIT Rourkela graduates, software solutions, industrial IoT for predictive plant maintenance, and robotics.',
      hiring: 'Full-stack software engineers, IoT firmware developers, AI/ML researchers'
    },
    {
      title: 'Healthcare, Education & Commercial Services',
      desc: 'Vast healthcare network led by IGH, Apollo, and 15+ engineering and degree colleges providing steady professional employment.',
      hiring: 'Medical Specialists, Nursing professionals, College lecturers, Banking executives'
    }
  ];

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-slate-200">
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-800 text-xs font-bold mb-2">
          <Factory className="w-3.5 h-3.5" />
          <span>Industrial Hub & Career Opportunities</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
          Jobs, Industries & Business in Rourkela
        </h2>
        <p className="text-sm text-slate-600 mt-1 max-w-2xl">
          Rourkela's industrial economy is the powerhouse of Odisha. Explore verified corporate recruitment links, trade apprenticeships, and MSME clusters.
        </p>
      </div>

      {/* Advisory disclaimer box mandated by prompt section 12 */}
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl mb-8 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-900 leading-relaxed">
          <strong className="font-bold block mb-0.5 text-amber-950">
            Advisory on Job Applications & Authenticity:
          </strong>
          SAIL, NIT Rourkela, and Government departments never charge fees for recruitment selection. Apply exclusively through official government portals. Check application closing dates and vacancy notification PDF before applying.
        </div>
      </div>

      {/* TIIR Deep-Tech Innovation & Startup Spotlight */}
      <div className="mb-10 bg-gradient-to-br from-indigo-900/10 via-sky-800/5 to-slate-900/5 rounded-3xl p-6 sm:p-8 border border-indigo-200/80 shadow-md">
        <div className="flex flex-col lg:flex-row gap-8 items-center">
          <div className="relative w-full lg:w-1/2 shrink-0">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[4/3] bg-slate-900 group">
              <img
                src="/assets/aistudio/TIIR_8cd3f598.webp"
                alt="TIIR — Technology Innovation & Industry Relations Building at NIT Rourkela Campus"
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />
              <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-indigo-900 flex items-center gap-1.5 shadow-sm">
                <Rocket className="w-3.5 h-3.5 text-indigo-600" />
                <span>Nodal Incubator • Startup Odisha & DST</span>
              </div>
              <div className="absolute bottom-3 left-3 right-3 text-white">
                <p className="text-[11px] text-indigo-300 font-semibold uppercase tracking-wider">
                  NIT Rourkela Deep-Tech Park
                </p>
                <h4 className="text-lg sm:text-xl font-bold">TIIR Centre for Innovation & Incubation</h4>
                <p className="text-xs text-slate-300">Sector 1, NIT Campus, Rourkela 769008</p>
              </div>
            </div>
          </div>

          <div className="flex-1 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 text-indigo-900 text-xs font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Grants up to ₹25 Lakhs • Hardware FabLab</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
              TIIR: Technology Innovation & Industry Relations
            </h3>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              The flagship entrepreneurship park at NIT Rourkela, supported by the <strong>Department of Science and Technology (DST)</strong> and <strong>Startup Odisha</strong>. Providing seed funding, pre-incubation, rapid prototyping facilities, patent filing support, and venture mentorship for deep-tech entrepreneurs in robotics, IoT, renewable power, and metallurgical AI.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-slate-400 block mb-0.5 font-medium">Seed Funding</span>
                <strong className="text-emerald-700 text-sm">Up to ₹25 Lakhs / Startup</strong>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-slate-400 block mb-0.5 font-medium">Lab Infrastructure</span>
                <strong className="text-slate-800 text-sm">FabLab & 3D Prototyping</strong>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-slate-400 block mb-0.5 font-medium">Verified Phone</span>
                <strong className="text-slate-800 text-sm">0661-2462060</strong>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                <span className="text-slate-400 block mb-0.5 font-medium">Location</span>
                <strong className="text-slate-800">Sector 1, NIT Campus</strong>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <a
                href="https://tiir.nitrkl.ac.in"
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-colors"
              >
                <span>Apply for Incubation at TIIR ↗</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href="https://www.google.com/maps/dir/?api=1&destination=22.2515,84.9030"
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-white text-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors"
              >
                <Navigation className="w-3.5 h-3.5 text-indigo-600" />
                <span>Directions to TIIR Building ↗</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Official Recruitment Portals Grid */}
      <h3 className="text-lg font-bold text-slate-900 mb-4 font-display">
        Verified Institutional Recruitment Portals
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
        {officialPortals.map((portal, i) => (
          <div
            key={i}
            className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-sky-300 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-sky-50 text-sky-800 uppercase">
                  Verified Portal
                </span>
                <span className="text-emerald-600 text-xs font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Official Source
                </span>
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-1">
                {portal.title}
              </h4>
              <p className="text-xs text-slate-500 font-medium mb-2">{portal.agency}</p>
              <p className="text-xs text-slate-700 mb-2">
                <strong>Key Roles:</strong> {portal.roles}
              </p>
              <p className="text-xs text-slate-500 mb-4 italic">
                {portal.notes}
              </p>
            </div>

            <a
              href={portal.portalUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
            >
              <span>Visit Official Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        ))}
      </div>

      {/* Industrial Landscape */}
      <h3 className="text-lg font-bold text-slate-900 mb-4 font-display">
        Core Industrial Sectors in Rourkela
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {industrialSectors.map((sector, i) => (
          <div key={i} className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
            <h4 className="text-sm font-bold text-slate-900 mb-2">{sector.title}</h4>
            <p className="text-xs text-slate-600 leading-relaxed mb-3">
              {sector.desc}
            </p>
            <div className="text-[11px] text-slate-500 bg-white p-2.5 rounded-xl border border-slate-200">
              <strong className="text-slate-800 block mb-0.5">Key Talent Demands:</strong>
              {sector.hiring}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
