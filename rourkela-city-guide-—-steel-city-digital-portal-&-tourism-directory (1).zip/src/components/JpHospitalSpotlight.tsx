import React from 'react';
import { 
  HeartPulse, 
  MapPin, 
  Phone, 
  Navigation, 
  CheckCircle2, 
  ExternalLink,
  Clock,
  Sparkles,
  Stethoscope,
  Building2,
  Ambulance,
  ShieldAlert
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';
import { cleanPhoneForDialing } from '../utils/directoryUtils';

interface JpHospitalSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  jpHospitalItem?: DirectoryItem;
}

export const JpHospitalSpotlight: React.FC<JpHospitalSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  jpHospitalItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-teal-900/10 via-emerald-800/5 to-slate-900/5 rounded-3xl p-6 sm:p-8 border border-emerald-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[16/10] bg-slate-900 group">
            <img
              src="/assets/aistudio/JP_a2a10ef8.jpg"
              alt="Jaiprakash Hospital and Research Centre Pvt Ltd - Main Building & 24/7 Emergency Wing, NH-143 Rourkela"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-teal-950 flex items-center gap-1.5 shadow-sm">
              <Building2 className="w-3.5 h-3.5 text-teal-600" />
              <span>NABH-Accredited 250-Bed Multi-Speciality</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-teal-300 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>24/7 Highway Polytrauma & Critical Care Wing</span>
              </p>
              <h4 className="text-lg sm:text-xl font-bold">JP Hospital & Research Centre</h4>
              <p className="text-xs text-slate-300">NH-143, Dandiapali / Near Uditnagar, Rourkela 769004</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>NABH Accredited Polytrauma, Joint Replacement & Cancer Care</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            JP Hospital & Research Centre
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Strategically located along NH-143 connecting Rourkela with southern Odisha and Jharkhand, <strong>Jaiprakash Hospital & Research Centre</strong> is a premier 250-bed multi-speciality tertiary healthcare institute. It features a specialized level-3 emergency trauma department, 20-bed advanced haemodialysis wing, neonatal & pediatric ICU (NICU/PICU), and complete diagnostic pathology.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <HeartPulse className="w-3.5 h-3.5 text-emerald-600" />
                <span className="font-medium">Key Specialities</span>
              </div>
              <strong className="text-slate-800 text-sm">Polytrauma, Ortho, GI Surgery & Oncology</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <MapPin className="w-3.5 h-3.5 text-teal-600" />
                <span className="font-medium">Highway Access</span>
              </div>
              <strong className="text-slate-800 text-sm">NH-143 Dandiapali (Near Uditnagar)</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                <span className="font-medium">24/7 Trauma Helpline</span>
              </div>
              <strong className="text-rose-700 text-sm">0661-2464111</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <Phone className="w-3.5 h-3.5 text-teal-600" />
                <span className="font-medium">Hospital Reception / OPD</span>
              </div>
              <strong className="text-teal-700 text-sm">0661-2464100</strong>
            </div>
          </div>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            {jpHospitalItem && (
              <>
                <button
                  onClick={() => onSelectItem(jpHospitalItem)}
                  className="px-4 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs sm:text-sm flex items-center gap-2 shadow-sm transition-all"
                >
                  <Stethoscope className="w-4 h-4" />
                  <span>View Hospital Details & Doctors</span>
                </button>

                <button
                  onClick={() => onLocateOnMap(jpHospitalItem)}
                  className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shadow-2xs"
                >
                  <Navigation className="w-4 h-4 text-teal-600" />
                  <span>Locate on NH-143 on Map</span>
                </button>
              </>
            )}

            <a
              href="tel:06612464111"
              className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm transition-all"
            >
              <Phone className="w-4 h-4" />
              <span>Call Trauma Casualty: 0661-2464111</span>
            </a>

            <a
              href="https://jphospital.in"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2.5 rounded-xl text-slate-600 hover:text-slate-900 font-semibold text-xs flex items-center gap-1 hover:underline"
            >
              <span>JP Hospital Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
