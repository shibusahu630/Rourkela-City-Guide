import React from 'react';
import { 
  Compass, 
  MapPin, 
  Clock, 
  Navigation, 
  CheckCircle2, 
  Sparkles, 
  Trees, 
  Phone,
  Mountain
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';

interface KhandadharSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  khandadharItem?: DirectoryItem;
}

export const KhandadharSpotlight: React.FC<KhandadharSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  khandadharItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-emerald-900/10 via-teal-800/5 to-slate-900/5 rounded-3xl p-6 sm:p-8 border border-emerald-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-2/5 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[3/4] max-h-[440px] bg-slate-900 group">
            <img
              src="/assets/aistudio/khandadhar_9292eb36.jpg"
              alt="Khandadhar Waterfall scenic viewpoint stairs and cascade, Sundargarh"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-emerald-900 flex items-center gap-1.5 shadow-sm">
              <Mountain className="w-3.5 h-3.5 text-emerald-600" />
              <span>244m (801 ft) Sheer Drop • 2nd Highest in Odisha</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-emerald-300 font-semibold uppercase tracking-wider">
                Eco-Tourism & Nature Trail
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Khandadhar Waterfall</h4>
              <p className="text-xs text-slate-300">Bonaigarh Sub-division, Sundargarh (~75 km from Rourkela)</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Signature Eco-Tourism & Day-Trip Destination</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Khandadhar Waterfall: The Glistening Sword of Nature
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Cascading down a sheer vertical rock face of <strong>244 metres (801 feet)</strong>, Khandadhar is the second highest waterfall in Odisha and the 12th highest in India. The plummeting waters resemble a sparkling sword (\'Khanda\'), creating a permanent rainbow mist amidst pristine tribal sal forests. Developed with well-paved walking stairs, viewpoint pavilions, and eco-tourism cottages.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Vertical Waterfall Drop</span>
              <strong className="text-slate-800 text-sm">244m (801 ft) Plunge</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Distance from City</span>
              <strong className="text-slate-800 text-sm">~75 km via NH-143 (Day Trip)</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Visiting Timings</span>
              <strong className="text-emerald-700 text-sm">08:00 AM – 05:00 PM</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Entry Ticket</span>
              <strong className="text-slate-800">₹20 per adult (Eco-Development)</strong>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <a
              href="https://www.google.com/maps/dir/?api=1&destination=21.8340,84.9080"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-colors"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Get Directions to Khandadhar ↗</span>
            </a>

            {khandadharItem && (
              <>
                <button
                  onClick={() => onLocateOnMap(khandadharItem)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-white text-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <MapPin className="w-3.5 h-3.5 text-sky-600" />
                  <span>Locate on Interactive Map</span>
                </button>

                <button
                  onClick={() => onSelectItem(khandadharItem)}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
                >
                  <span>Full Profile & Details →</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
