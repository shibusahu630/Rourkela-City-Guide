import React from 'react';
import { 
  MapPin, 
  Clock, 
  Navigation, 
  CheckCircle2, 
  Sparkles, 
  Phone,
  Waves,
  Mountain,
  Sun,
  ShieldCheck,
  Ship,
  Compass
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';

interface MandiraDamSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  mandiraItem?: DirectoryItem;
}

export const MandiraDamSpotlight: React.FC<MandiraDamSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  mandiraItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-cyan-950/10 via-sky-900/5 to-emerald-950/5 rounded-3xl p-6 sm:p-8 border border-cyan-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[4/3] bg-slate-900 group">
            <img
              src="/assets/aistudio/mandira_4e339f25.jpg"
              alt="Mandira Dam concrete spillway floodgates discharging surging Sankha river waters into the reservoir basin"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-cyan-950 flex items-center gap-1.5 shadow-sm">
              <Waves className="w-3.5 h-3.5 text-cyan-600" />
              <span>Sankha River • RSP Water Lifeline</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-cyan-300 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>Multi-Bay Spillway & Scenic Reservoir</span>
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Mandira Dam & Reservoir</h4>
              <p className="text-xs text-slate-300">Sankha River, Mandira (~16 km West of Rourkela), Odisha</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-100 text-cyan-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-cyan-700" />
            <span>Lifeline Reservoir & Premier Lakeside Retreat</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Mandira Dam & Reservoir
          </h3>

          <p className="text-sm text-slate-600 leading-relaxed">
            Constructed across the Sankha river in 1957–1959 by SAIL to secure industrial and municipal water supply for the Rourkela Steel Plant. Nestled amidst the emerald rolling hills of the Chota Nagpur plateau, Mandira Dam features an impressive multi-gate concrete spillway, a tranquil lake with boating facilities, manicured lakeside gardens, and the SAIL inspection bungalow, making it Rourkela’s premier weekend picnic and nature getaway.
          </p>

          {/* Feature Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-cyan-700 text-xs font-bold mb-0.5">
                <Waves className="w-3.5 h-3.5 text-cyan-600" />
                <span>Spillway Gates</span>
              </div>
              <p className="text-[11px] text-slate-500">Multi-bay Flood Discharge</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-blue-700 text-xs font-bold mb-0.5">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                <span>SAIL RSP Lifeline</span>
              </div>
              <p className="text-[11px] text-slate-500">Built 1957–1959 for Steel City</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold mb-0.5">
                <Ship className="w-3.5 h-3.5 text-emerald-600" />
                <span>Boating & Lake</span>
              </div>
              <p className="text-[11px] text-slate-500">Motor & Paddle Boat Rides</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-teal-700 text-xs font-bold mb-0.5">
                <Mountain className="w-3.5 h-3.5 text-teal-600" />
                <span>Emerald Hills</span>
              </div>
              <p className="text-[11px] text-slate-500">Chota Nagpur Plateau</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-amber-700 text-xs font-bold mb-0.5">
                <Sun className="w-3.5 h-3.5 text-amber-600" />
                <span>Picnic Lawns</span>
              </div>
              <p className="text-[11px] text-slate-500">Lakeside Gardens & Bungalow</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-700 text-xs font-bold mb-0.5">
                <Clock className="w-3.5 h-3.5 text-slate-600" />
                <span>Gate Hours</span>
              </div>
              <p className="text-[11px] text-slate-500">07:00 AM – 06:00 PM</p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap gap-3">
            <a
              href="tel:06612642010"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-700 hover:bg-cyan-800 text-white font-semibold text-xs sm:text-sm shadow-sm transition-all"
            >
              <Phone className="w-4 h-4" />
              <span>Inquiry / Tourism (0661-2642010)</span>
            </a>

            {mandiraItem && (
              <>
                <button
                  onClick={() => onLocateOnMap(mandiraItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-xs sm:text-sm border border-slate-300 shadow-2xs transition-all"
                >
                  <MapPin className="w-4 h-4 text-cyan-600" />
                  <span>Locate on Map</span>
                </button>

                <button
                  onClick={() => onSelectItem(mandiraItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-50 hover:bg-cyan-100 text-cyan-900 font-semibold text-xs sm:text-sm border border-cyan-300 shadow-2xs transition-all"
                >
                  <Sparkles className="w-4 h-4 text-cyan-600" />
                  <span>View Details & Guide</span>
                </button>
              </>
            )}

            <a
              href="https://maps.google.com/?q=22.2740,84.6730"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs sm:text-sm border border-slate-300 shadow-2xs transition-all"
            >
              <Navigation className="w-4 h-4 text-sky-600" />
              <span>Directions</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
