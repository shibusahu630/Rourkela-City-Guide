import React, { useState } from 'react';
import { 
  Building2, 
  MapPin, 
  PhoneCall, 
  PlusCircle, 
  ShieldCheck, 
  Menu, 
  X, 
  Compass, 
  GraduationCap, 
  HeartPulse, 
  Utensils, 
  Bus, 
  Bed, 
  Briefcase 
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenEmergency: () => void;
  onOpenSubmit: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenEmergency,
  onOpenSubmit,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'overview', label: 'Overview', icon: Compass },
    { id: 'map', label: 'City Map', icon: MapPin },
    { id: 'attractions', label: 'Tourism', icon: Compass },
    { id: 'education', label: 'Schools & Colleges', icon: GraduationCap },
    { id: 'health', label: 'Healthcare', icon: HeartPulse },
    { id: 'dining', label: 'Food & Dining', icon: Utensils },
    { id: 'hotels', label: 'Hotels', icon: Bed },
    { id: 'transport', label: 'Transit', icon: Bus },
    { id: 'neighbourhoods', label: 'Localities', icon: Building2 },
    { id: 'business', label: 'Jobs & Industry', icon: Briefcase },
  ];

  const handleSelectTab = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top micro bar with official disclaimer and quick emergency button */}
      <div className="bg-slate-900 text-slate-200 text-xs py-1.5 px-4 sm:px-8 flex justify-between items-center">
        <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
          <span className="inline-flex items-center gap-1 text-emerald-400 font-medium">
            <ShieldCheck className="w-3.5 h-3.5" />
            Verified City Portal
          </span>
          <span className="hidden md:inline text-slate-400">•</span>
          <span className="hidden md:inline text-slate-300">
            Steel City of Odisha — Sundargarh District
          </span>
          <span className="hidden lg:inline text-slate-500">•</span>
          <span className="hidden lg:inline text-slate-400">
            All data cross-referenced with official institution sources
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenEmergency}
            className="inline-flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold px-2.5 py-0.5 rounded-full text-xs shadow-xs transition-colors animate-pulse"
            aria-label="Open emergency contacts"
          >
            <PhoneCall className="w-3 h-3" />
            <span>24/7 SOS & Hospital ER</span>
          </button>
          <button
            onClick={onOpenSubmit}
            className="hidden sm:inline-flex items-center gap-1 text-slate-300 hover:text-white transition-colors"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>List Business / Edit</span>
          </button>
        </div>
      </div>

      {/* Main navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo & City Identity */}
          <button
            onClick={() => handleSelectTab('overview')}
            className="flex items-center gap-3 text-left group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-700 to-indigo-600 flex items-center justify-center text-white shadow-md font-bold text-xl tracking-tight group-hover:scale-105 transition-transform">
              R
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-slate-900 font-display">
                  ROURKELA
                </span>
                <span className="bg-sky-100 text-sky-800 text-[10px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider">
                  City Guide
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                The Steel City of Odisha
              </p>
            </div>
          </button>

          {/* Desktop Nav Items */}
          <nav className="hidden xl:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelectTab(item.id)}
                  className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-sky-50 text-sky-700 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-sky-600' : 'text-slate-400'}`} />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* CTA & Mobile Toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenSubmit}
              className="hidden md:inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors"
            >
              <PlusCircle className="w-4 h-4 text-sky-600" />
              <span>Add Listing</span>
            </button>
            <button
              onClick={() => handleSelectTab('map')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white shadow-xs transition-colors"
            >
              <MapPin className="w-4 h-4" />
              <span>Explore Map</span>
            </button>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100"
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white border-b border-slate-200 shadow-xl px-4 pt-2 pb-6 space-y-1">
          <div className="grid grid-cols-2 gap-2 pt-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleSelectTab(item.id)}
                  className={`flex items-center gap-2 p-2.5 rounded-lg text-xs font-medium text-left transition-colors ${
                    isActive
                      ? 'bg-sky-50 text-sky-700 font-bold border border-sky-200'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-sky-600' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
          <div className="pt-3 border-t border-slate-200 flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenSubmit();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 text-xs font-semibold py-2.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50"
            >
              <PlusCircle className="w-4 h-4 text-sky-600" />
              <span>List Your Business or Suggest Edit</span>
            </button>
            <button
              onClick={() => {
                onOpenEmergency();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 text-xs font-bold py-2.5 rounded-lg bg-rose-600 text-white shadow-xs"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Emergency 24/7 Hotlines & Hospitals</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
