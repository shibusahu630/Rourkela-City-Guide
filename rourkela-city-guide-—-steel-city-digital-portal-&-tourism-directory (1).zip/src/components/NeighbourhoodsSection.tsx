import React, { useState } from 'react';
import { LOCALITIES_DATA } from '../data/rourkelaData';
import { LocalityInfo, LocalityType } from '../types/directory';
import { Building2, MapPin, Bus, CheckCircle2, ChevronRight, Search } from 'lucide-react';

interface NeighbourhoodsSectionProps {
  onSelectLocality: (locality: LocalityType) => void;
}

export const NeighbourhoodsSection: React.FC<NeighbourhoodsSectionProps> = ({
  onSelectLocality,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLocalities = LOCALITIES_DATA.filter(loc => 
    loc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    loc.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    loc.tagline.toLowerCase().includes(searchTerm.toLowerCase()) ||
    loc.keyFeatures.some(f => f.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-slate-200">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-100 text-indigo-800 text-xs font-bold mb-2">
            <Building2 className="w-3.5 h-3.5" />
            <span>Searchable Neighbourhood Profiles</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Localities & Neighbourhoods of Rourkela
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            Explore Rourkela by sector and locality. Search nearby schools, hospitals, local markets, and public transit links in each neighborhood.
          </p>
        </div>

        {/* Search inside localities */}
        <div className="relative sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search localities..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredLocalities.map((loc) => (
          <div
            key={loc.name}
            className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:shadow-lg hover:border-sky-300 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-bold text-sky-700 bg-sky-50 px-2.5 py-0.5 rounded-md">
                  PIN: {loc.pincode}
                </span>
                <span className="text-[11px] text-slate-400 font-medium">Sundargarh Dist</span>
              </div>

              <h3 className="text-lg font-bold text-slate-900 mb-1 font-display">
                {loc.name}
              </h3>
              <p className="text-xs font-medium text-slate-500 mb-3 italic">
                "{loc.tagline}"
              </p>

              <p className="text-xs text-slate-600 leading-relaxed mb-4">
                {loc.description}
              </p>

              {/* Landmark & Transit */}
              <div className="space-y-2 mb-4 text-xs">
                <div className="flex items-start gap-1.5 text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-semibold block text-slate-900">Key Landmark:</strong>
                    <span>{loc.landmark}</span>
                  </div>
                </div>

                <div className="flex items-start gap-1.5 text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                  <Bus className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-semibold block text-slate-900">Transit Links:</strong>
                    <span>{loc.transportLinks}</span>
                  </div>
                </div>
              </div>

              {/* Key Features */}
              <div className="flex flex-wrap gap-1.5 mb-4">
                {loc.keyFeatures.map((feat, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md"
                  >
                    • {feat}
                  </span>
                ))}
              </div>
            </div>

            <button
              onClick={() => onSelectLocality(loc.name)}
              className="w-full mt-2 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-2xs"
            >
              <span>Explore Places in {loc.name}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </section>
  );
};
