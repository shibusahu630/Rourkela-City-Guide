import React, { useState } from 'react';
import { 
  GraduationCap, 
  MapPin, 
  Phone, 
  Navigation, 
  CheckCircle2, 
  Sparkles, 
  ExternalLink,
  BookOpen,
  Award,
  Building2,
  Rocket,
  Cpu
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';

interface NitRourkelaSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  nitItem?: DirectoryItem;
}

export const NitRourkelaSpotlight: React.FC<NitRourkelaSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  nitItem
}) => {
  const [activeTab, setActiveTab] = useState<'admin' | 'tiir'>('admin');

  return (
    <div className="mb-10 bg-gradient-to-br from-indigo-900/10 via-sky-800/5 to-slate-900/5 rounded-3xl p-6 sm:p-8 border border-indigo-200/80 shadow-md">
      {/* Campus Facility Switcher Tab */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6 pb-4 border-b border-indigo-100">
        <div className="flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-indigo-700" />
          <span className="text-xs sm:text-sm font-bold text-slate-800 uppercase tracking-wider">
            NIT Rourkela Campus Showcase:
          </span>
        </div>

        <div className="inline-flex rounded-xl p-1 bg-white border border-indigo-200 text-xs font-semibold shadow-2xs">
          <button
            onClick={() => setActiveTab('admin')}
            className={`px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'admin'
                ? 'bg-indigo-600 text-white shadow-xs font-bold'
                : 'text-slate-600 hover:text-indigo-700'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Main Admin Building</span>
          </button>
          <button
            onClick={() => setActiveTab('tiir')}
            className={`px-3.5 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'tiir'
                ? 'bg-indigo-600 text-white shadow-xs font-bold'
                : 'text-slate-600 hover:text-indigo-700'
            }`}
          >
            <Rocket className="w-3.5 h-3.5" />
            <span>TIIR Innovation & Startups</span>
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photograph showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[4/3] bg-slate-900 group">
            {activeTab === 'admin' ? (
              <img
                src="/assets/aistudio/nit_rourkela_ed9519e8.webp"
                alt="National Institute of Technology Rourkela (NIT Rourkela) Main Administrative Building, Sector 1"
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
              />
            ) : (
              <img
                src="/assets/aistudio/TIIR_8cd3f598.webp"
                alt="TIIR — Technology Innovation & Industry Relations Building, NIT Rourkela Campus"
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-indigo-900 flex items-center gap-1.5 shadow-sm">
              {activeTab === 'admin' ? (
                <>
                  <Award className="w-3.5 h-3.5 text-amber-500" />
                  <span>NIRF Top 20 National Engineering Rank</span>
                </>
              ) : (
                <>
                  <Cpu className="w-3.5 h-3.5 text-emerald-600" />
                  <span>DST Supported • Startup Odisha Incubator</span>
                </>
              )}
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-indigo-300 font-semibold uppercase tracking-wider">
                {activeTab === 'admin' 
                  ? 'Institute of National Importance • Estd. 1961' 
                  : 'Deep-Tech Incubation & Research Park • NIT Rourkela'}
              </p>
              <h4 className="text-lg sm:text-xl font-bold">
                {activeTab === 'admin' 
                  ? 'National Institute of Technology Rourkela' 
                  : 'TIIR — Technology Innovation & Industry Relations'}
              </h4>
              <p className="text-xs text-slate-300">
                {activeTab === 'admin'
                  ? 'Sector 1, Steel Township, Rourkela 769008'
                  : 'TIIR Centre, NIT Rourkela Campus, Sector 1, Rourkela'}
              </p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 text-indigo-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>
              {activeTab === 'admin' 
                ? 'Ministry of Education, Govt. of India • NITSER Act' 
                : 'Recognized Nodal Incubator • Startup Odisha & DST'}
            </span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            {activeTab === 'admin' 
              ? 'NIT Rourkela: Premier Technical & Research Hub'
              : 'TIIR: Powering Western Odisha\'s Deep-Tech Startups'}
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            {activeTab === 'admin' ? (
              <>
                Founded in <strong>1961</strong> as the <em>Regional Engineering College (REC) Rourkela</em> and elevated to an <strong>Institute of National Importance</strong>, NIT Rourkela is one of India&apos;s leading technical universities. Set across a serene <strong>647-acre campus</strong> in Sector 1, it hosts 20 academic departments spanning undergraduate, postgraduate, and doctoral degrees with world-class supercomputing facilities, the TIIR startup incubator, and over 7,000 scholars.
              </>
            ) : (
              <>
                The <strong>Technology Innovation & Industry Relations (TIIR)</strong> centre is NIT Rourkela&apos;s dedicated research and entrepreneurship park. Backed by the <strong>Department of Science & Technology (DST)</strong> and <strong>Startup Odisha</strong>, it provides physical co-working, seed funding up to <strong>₹25 Lakhs</strong>, rapid prototyping FabLabs, and industry-sponsored R&D bridging academic breakthroughs with commercial enterprises.
              </>
            )}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {activeTab === 'admin' ? (
              <>
                <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                  <span className="text-slate-400 block mb-0.5 font-medium">Campus Area & Facilities</span>
                  <strong className="text-slate-800 text-sm">647 Acres • 11 Residence Halls</strong>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                  <span className="text-slate-400 block mb-0.5 font-medium">Academic Departments</span>
                  <strong className="text-slate-800 text-sm">20 Depts (Engineering, Science, MBA)</strong>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                  <span className="text-slate-400 block mb-0.5 font-medium">Official Contact Helpline</span>
                  <strong className="text-emerald-700 text-sm">0661-2462020</strong>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                  <span className="text-slate-400 block mb-0.5 font-medium">Innovation & Startups</span>
                  <strong className="text-slate-800">TIIR Park & Global Placements</strong>
                </div>
              </>
            ) : (
              <>
                <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                  <span className="text-slate-400 block mb-0.5 font-medium">Seed Funding Support</span>
                  <strong className="text-emerald-700 text-sm">Up to ₹25 Lakhs / Startup</strong>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                  <span className="text-slate-400 block mb-0.5 font-medium">Prototyping & Labs</span>
                  <strong className="text-slate-800 text-sm">FabLab, 3D Print & Hardware Testing</strong>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                  <span className="text-slate-400 block mb-0.5 font-medium">TIIR Office Contact</span>
                  <strong className="text-indigo-700 text-sm">0661-2462060</strong>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                  <span className="text-slate-400 block mb-0.5 font-medium">Focus Sectors</span>
                  <strong className="text-slate-800">AI, IoT, Clean Energy, MedTech</strong>
                </div>
              </>
            )}
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <a
              href={activeTab === 'admin' 
                ? "https://www.google.com/maps/dir/?api=1&destination=22.2530,84.9015"
                : "https://www.google.com/maps/dir/?api=1&destination=22.2515,84.9030"}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-colors"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>
                {activeTab === 'admin' ? 'Get Directions to NIT Campus ↗' : 'Get Directions to TIIR Building ↗'}
              </span>
            </a>

            <a
              href={activeTab === 'admin' ? "https://www.nitrkl.ac.in" : "https://tiir.nitrkl.ac.in"}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-white text-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5 text-indigo-600" />
              <span>
                {activeTab === 'admin' ? 'NIT Portal (nitrkl.ac.in) ↗' : 'TIIR Incubator Portal ↗'}
              </span>
            </a>

            {nitItem && (
              <>
                <button
                  onClick={() => onLocateOnMap(nitItem)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-white text-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <MapPin className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Locate on Map</span>
                </button>

                <button
                  onClick={() => onSelectItem(nitItem)}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
                >
                  <span>Academic Details →</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
