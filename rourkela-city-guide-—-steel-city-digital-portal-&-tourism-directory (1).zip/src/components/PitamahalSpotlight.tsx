import React from 'react';
import { 
  MapPin, 
  Clock, 
  Navigation, 
  CheckCircle2, 
  Sparkles, 
  Phone,
  Waves,
  Mountain,
  Trees,
  Compass,
  Binoculars,
  Camera
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';

interface PitamahalSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  pitamahalItem?: DirectoryItem;
}

export const PitamahalSpotlight: React.FC<PitamahalSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  pitamahalItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-emerald-950/10 via-teal-900/5 to-cyan-950/5 rounded-3xl p-6 sm:p-8 border border-emerald-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[16/9] sm:aspect-[4/3] bg-slate-900 group">
            <img
              src="/assets/aistudio/pitamahal_8e4497e1.jpg"
              alt="Pitamahal Dam aerial vista showing the curved masonry dyke, blue reservoir waters, and lush sal forest hills"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-emerald-950 flex items-center gap-1.5 shadow-sm">
              <Waves className="w-3.5 h-3.5 text-teal-600" />
              <span>Kalunga Outskirts • Pitamahal River</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-teal-300 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>Curved Dam Dyke & Forested Reservoir Basin</span>
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Pitamahal Dam & Nature Reserve</h4>
              <p className="text-xs text-slate-300">Pitamahal River, Kalunga Outskirts, ~18 km South of Rourkela</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 text-emerald-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-700" />
            <span>Eco Lake & Migratory Bird Sanctuary</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Pitamahal Dam & Nature Reserve
          </h3>

          <p className="text-sm text-slate-600 leading-relaxed">
            Constructed across the Pitamahal River on the southwestern fringes of Sundargarh district, Pitamahal Dam features a graceful curved masonry and earthen embankment cradling an expansive azure reservoir. Flanked by rolling green hills blanketed in dense sal and reserve forests, Pitamahal is acclaimed as Rourkela’s most peaceful eco-retreat—frequented by winter migratory waterfowl, birding enthusiasts, and families seeking quiet nature picnics away from the steel city.
          </p>

          {/* Feature Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-teal-700 text-xs font-bold mb-0.5">
                <Waves className="w-3.5 h-3.5 text-teal-600" />
                <span>Curved Embankment</span>
              </div>
              <p className="text-[11px] text-slate-500">Masonry dyke overlooking the serene waters</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold mb-0.5">
                <Mountain className="w-3.5 h-3.5 text-emerald-600" />
                <span>Sal Forest Hills</span>
              </div>
              <p className="text-[11px] text-slate-500">Verdant green slopes surrounding the catchment</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-cyan-700 text-xs font-bold mb-0.5">
                <Binoculars className="w-3.5 h-3.5 text-cyan-600" />
                <span>Winter Birding</span>
              </div>
              <p className="text-[11px] text-slate-500">Waterfowl, egrets, and seasonal migratory flocks</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-amber-700 text-xs font-bold mb-0.5">
                <Trees className="w-3.5 h-3.5 text-amber-600" />
                <span>Picnic Haven</span>
              </div>
              <p className="text-[11px] text-slate-500">Quiet lakeside clearings for family day-outs</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-purple-700 text-xs font-bold mb-0.5">
                <Compass className="w-3.5 h-3.5 text-purple-600" />
                <span>Kalunga Route</span>
              </div>
              <p className="text-[11px] text-slate-500">~18 km south from city center via Kalunga</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-blue-700 text-xs font-bold mb-0.5">
                <Clock className="w-3.5 h-3.5 text-blue-600" />
                <span>07:00 AM – 05:30 PM</span>
              </div>
              <p className="text-[11px] text-slate-500">Day visits recommended; free public entry</p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <a
              href="tel:06612400300"
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call Tourism: 0661-2400300</span>
            </a>

            {pitamahalItem && (
              <>
                <button
                  onClick={() => onLocateOnMap(pitamahalItem)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-sm transition-colors"
                >
                  <MapPin className="w-3.5 h-3.5 text-teal-400" />
                  <span>Locate on Map</span>
                </button>

                <button
                  onClick={() => onSelectItem(pitamahalItem)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold border border-slate-200 transition-colors"
                >
                  <span>View Details</span>
                </button>
              </>
            )}

            <a
              href="https://www.google.com/maps/search/?api=1&query=Pitamahal+Dam+Rourkela+Kalunga"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-teal-50 hover:bg-teal-100 text-teal-800 rounded-xl text-xs font-semibold border border-teal-200 transition-colors"
            >
              <Navigation className="w-3.5 h-3.5 text-teal-600" />
              <span>Get Directions</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
