import React from 'react';
import { 
  HeartPulse, 
  MapPin, 
  Phone, 
  Navigation, 
  CheckCircle2, 
  ExternalLink,
  Clock,
  Sparkles,
  Building2,
  Ambulance,
  ShieldCheck,
  Pill,
  Baby
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';
import { cleanPhoneForDialing } from '../utils/directoryUtils';

interface RghHospitalSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  rghItem?: DirectoryItem;
}

export const RghHospitalSpotlight: React.FC<RghHospitalSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  rghItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-blue-900/10 via-sky-800/5 to-slate-900/5 rounded-3xl p-6 sm:p-8 border border-blue-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[16/10] bg-slate-900 group">
            <img
              src="/assets/aistudio/RGH_1618768712_38ccb2f3.webp"
              alt="Rourkela Government Hospital (RGH) - Out Patient Department & Emergency Casualty Wing"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-blue-950 flex items-center gap-1.5 shadow-sm">
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
              <span>District Govt Headquarters Hospital • 400+ Beds</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-blue-300 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>24/7 Casualty & 108 Emergency Ambulance Hub</span>
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Rourkela Government Hospital (RGH)</h4>
              <p className="text-xs text-slate-300">ରାଉରକେଲା ସରକାରୀ ଚିକିତ୍ସାଳୟ • Panposh Road, Rourkela 769004</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 text-blue-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
            <span>State Government Free & Cashless Healthcare (BSKY & AB-PMJAY)</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Rourkela Government Hospital (RGH)
          </h3>

          <p className="text-sm text-slate-600 leading-relaxed">
            The principal state government healthcare facility serving civilian communities across Sundargarh and western Odisha. RGH provides 24/7 emergency casualty triage, modern Maternal & Child Health (MCH) wings, free state-subsidized dialysis, automated pathology diagnostics, and round-the-clock free medicines under the Niramaya scheme.
          </p>

          {/* Quick feature tags */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-blue-700 text-xs font-bold mb-0.5">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                <span>BSKY Cashless</span>
              </div>
              <p className="text-[11px] text-slate-500">100% Free Civilian Care</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-sky-700 text-xs font-bold mb-0.5">
                <Ambulance className="w-3.5 h-3.5 text-sky-600" />
                <span>108 / 102 Hub</span>
              </div>
              <p className="text-[11px] text-slate-500">Nodal Dispatch Station</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-rose-700 text-xs font-bold mb-0.5">
                <HeartPulse className="w-3.5 h-3.5 text-rose-600" />
                <span>24/7 Casualty</span>
              </div>
              <p className="text-[11px] text-slate-500">Emergency & Triage</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-purple-700 text-xs font-bold mb-0.5">
                <Baby className="w-3.5 h-3.5 text-purple-600" />
                <span>MCH Wing</span>
              </div>
              <p className="text-[11px] text-slate-500">Maternal & Child Health</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold mb-0.5">
                <Pill className="w-3.5 h-3.5 text-emerald-600" />
                <span>Niramaya Counter</span>
              </div>
              <p className="text-[11px] text-slate-500">Free Essential Medicines</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-amber-700 text-xs font-bold mb-0.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Dialysis Center</span>
              </div>
              <p className="text-[11px] text-slate-500">Free Nephro Dialysis</p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap gap-3">
            <a
              href="tel:06612400108"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-semibold text-xs sm:text-sm shadow-sm transition-all"
            >
              <Phone className="w-4 h-4" />
              <span>Call RGH Reception (0661-2400108)</span>
            </a>

            <a
              href="tel:108"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-semibold text-xs sm:text-sm shadow-sm transition-all"
            >
              <Ambulance className="w-4 h-4" />
              <span>Call 108 Govt Ambulance</span>
            </a>

            {rghItem && (
              <>
                <button
                  onClick={() => onSelectItem(rghItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold text-xs sm:text-sm transition-all"
                >
                  <ExternalLink className="w-4 h-4 text-slate-600" />
                  <span>View Full Details & OPD Timings</span>
                </button>

                <button
                  onClick={() => onLocateOnMap(rghItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold text-xs sm:text-sm transition-all"
                >
                  <Navigation className="w-4 h-4 text-blue-600" />
                  <span>Locate in Panposh on Map</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
