import React from 'react';
import { 
  GraduationCap, 
  MapPin, 
  Phone, 
  Navigation, 
  CheckCircle2, 
  Sparkles, 
  ExternalLink,
  BookOpen,
  Award,
  Building,
  Briefcase
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';
import { cleanPhoneForDialing } from '../utils/directoryUtils';

interface RimsSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  rimsItem?: DirectoryItem;
}

export const RimsSpotlight: React.FC<RimsSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  rimsItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-teal-900/10 via-emerald-800/5 to-slate-900/5 rounded-3xl p-6 sm:p-8 border border-teal-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[4/3] bg-slate-900 group">
            <img
              src="/assets/aistudio/RIMS_f1572f4f.jpg"
              alt="Rourkela Institute of Management Studies (RIMS) Chhend Campus building and entrance pavilion"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/15 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-teal-900 flex items-center gap-1.5 shadow-sm">
              <Award className="w-3.5 h-3.5 text-teal-600" />
              <span>Est. 1984 • Premier B-School in Western Odisha</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-teal-300 font-semibold uppercase tracking-wider">
                Management & Computer Applications
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Rourkela Institute of Management Studies</h4>
              <p className="text-xs text-slate-300">Institutional Area, Gopabandhu Nagar, Chhend, Rourkela</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 text-teal-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-teal-600" />
            <span>AICTE Approved • Affiliated with BPUT Odisha</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            RIMS Rourkela: Four Decades of Academic Excellence
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Founded in 1984, <strong>Rourkela Institute of Management Studies (RIMS)</strong> is one of Western Odisha\'s earliest and most reputed professional management and computing institutions. Situated across a lush green campus in the Chhend Institutional Area, it offers industry-aligned degrees, robust placement drives with top BFSI and corporate brands, and executive development programmes.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <BookOpen className="w-3.5 h-3.5 text-teal-600" />
                <span className="font-medium">Flagship Programs</span>
              </div>
              <strong className="text-slate-800 text-sm">MBA, MCA, BBA, BCA</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <Building className="w-3.5 h-3.5 text-teal-600" />
                <span className="font-medium">Campus Location</span>
              </div>
              <strong className="text-slate-800 text-sm">Chhend Institutional Area (PIN 769015)</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <Briefcase className="w-3.5 h-3.5 text-teal-600" />
                <span className="font-medium">Industry Liaison</span>
              </div>
              <strong className="text-slate-800">Recruiters: HDFC, ICICI, TCS, SAIL ecosystem</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-400 mb-0.5">
                <Phone className="w-3.5 h-3.5 text-teal-600" />
                <span className="font-medium">Admission Helpline</span>
              </div>
              <strong className="text-teal-700 text-sm">0661-2480437</strong>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <a
              href="https://www.google.com/maps/dir/?api=1&destination=22.2365,84.8120"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-colors"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Get Directions to RIMS</span>
              <ExternalLink className="w-3 h-3" />
            </a>

            <a
              href={`tel:${cleanPhoneForDialing('0661-2480437')}`}
              className="px-4 py-2.5 rounded-xl bg-white border border-teal-300 text-teal-900 font-bold text-xs flex items-center gap-2 hover:bg-teal-50 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-teal-600" />
              <span>Call Office (0661-2480437)</span>
            </a>

            <a
              href="https://rims-edu.com"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 font-bold text-xs flex items-center gap-2 transition-colors"
            >
              <GraduationCap className="w-3.5 h-3.5 text-teal-400" />
              <span>Official Website</span>
              <ExternalLink className="w-3 h-3" />
            </a>

            {rimsItem && (
              <>
                <button
                  onClick={() => onSelectItem(rimsItem)}
                  className="px-4 py-2.5 rounded-xl bg-white border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 transition-colors"
                >
                  View Full Profile
                </button>
                <button
                  onClick={() => onLocateOnMap(rimsItem)}
                  className="px-3.5 py-2.5 rounded-xl text-teal-700 hover:text-teal-900 font-bold text-xs flex items-center gap-1.5"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>Locate on Map</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
