import React from 'react';
import { 
  Factory, 
  MapPin, 
  Clock, 
  Navigation, 
  CheckCircle2, 
  Sparkles, 
  Phone,
  ShieldAlert,
  Flame,
  Award,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';

interface RspSteelPlantSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  rspItem?: DirectoryItem;
}

export const RspSteelPlantSpotlight: React.FC<RspSteelPlantSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  rspItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-amber-950/15 via-slate-900/10 to-orange-950/10 rounded-3xl p-6 sm:p-8 border border-amber-300/60 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-slate-700 aspect-[4/3] bg-slate-950 group">
            <img
              src="/assets/aistudio/RSP_fa8244eb.jpg"
              alt="Inside Rourkela Steel Plant (SAIL) heavy sinter strand, roller conveyor bed, gantry crane, and industrial steelmaking floor"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/25 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-amber-500/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-slate-950 flex items-center gap-1.5 shadow-md">
              <Factory className="w-3.5 h-3.5 text-slate-950" />
              <span>SAIL • India's 1st Integrated Public Sector Steel Plant (1955)</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-amber-400 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Flame className="w-3 h-3 text-orange-400" />
                <span>Heavy Rolling Mill & Blast Furnace Complex</span>
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Rourkela Steel Plant (SAIL) Heritage & Display</h4>
              <p className="text-xs text-slate-300">Sector 1–20 Steel Township / Main Gate, Rourkela, Sundargarh</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-950 text-xs font-bold border border-amber-300/80">
            <CheckCircle2 className="w-4 h-4 text-amber-600" />
            <span>Industrial Soul & Backbone of Rourkela • Steel Authority of India</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Rourkela Steel Plant (SAIL) Heritage
          </h3>

          <p className="text-sm text-slate-600 leading-relaxed">
            The defining industrial powerhouse of Rourkela and the foundation of modern Odisha's prosperity. Built with historic German engineering collaboration (Krupp and Demag), RSP pioneered the revolutionary LD oxygen process in Asia. It produces specialized defense plates for Indian Navy warships including INS Vikrant, silicon steel for electrical transformers, and crucial alloys for ISRO space missions.
          </p>

          {/* Feature Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-amber-700 text-xs font-bold mb-0.5">
                <Flame className="w-3.5 h-3.5 text-amber-600" />
                <span>LD Steelmaking</span>
              </div>
              <p className="text-[11px] text-slate-500">Pioneer in Asia (1950s)</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-sky-700 text-xs font-bold mb-0.5">
                <ShieldCheck className="w-3.5 h-3.5 text-sky-600" />
                <span>INS Vikrant Steel</span>
              </div>
              <p className="text-[11px] text-slate-500">DMR 249A Naval Grade</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-orange-700 text-xs font-bold mb-0.5">
                <Award className="w-3.5 h-3.5 text-orange-600" />
                <span>German Heritage</span>
              </div>
              <p className="text-[11px] text-slate-500">Krupp-Demag Consortium</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold mb-0.5">
                <Factory className="w-3.5 h-3.5 text-emerald-600" />
                <span>4.5 MTPA</span>
              </div>
              <p className="text-[11px] text-slate-500">Crude Steel Capacity</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-rose-700 text-xs font-bold mb-0.5">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                <span>Security Pass</span>
              </div>
              <p className="text-[11px] text-slate-500">SAIL PR Dept Approval</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-indigo-700 text-xs font-bold mb-0.5">
                <Clock className="w-3.5 h-3.5 text-indigo-600" />
                <span>Visitor Centre</span>
              </div>
              <p className="text-[11px] text-slate-500">10:00 AM – 04:00 PM</p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap gap-3">
            <a
              href="tel:06612510018"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs sm:text-sm shadow-sm transition-all"
            >
              <Phone className="w-4 h-4 text-amber-400" />
              <span>Call SAIL RSP PR (0661-2510018)</span>
            </a>

            <a
              href="https://sail.co.in/en/plants/rourkela-steel-plant"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs sm:text-sm shadow-sm transition-all"
            >
              <ExternalLink className="w-4 h-4" />
              <span>SAIL Official Portal</span>
            </a>

            {rspItem && (
              <>
                <button
                  onClick={() => onSelectItem(rspItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold text-xs sm:text-sm transition-all"
                >
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>View Details</span>
                </button>

                <button
                  onClick={() => onLocateOnMap(rspItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 font-semibold text-xs sm:text-sm transition-all"
                >
                  <Navigation className="w-4 h-4 text-sky-600" />
                  <span>Locate on Map</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
