import React from 'react';
import { 
  Trophy, 
  MapPin, 
  Clock, 
  Navigation, 
  CheckCircle2, 
  Sparkles, 
  Calendar,
  ExternalLink 
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';

interface StadiumSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  stadiumItem?: DirectoryItem;
}

export const StadiumSpotlight: React.FC<StadiumSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  stadiumItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-blue-900/10 via-sky-800/5 to-indigo-950/5 rounded-3xl p-6 sm:p-8 border border-sky-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[4/3] bg-slate-900 group">
            <img
              src="/assets/aistudio/birsa_munda_hockey_stadium_ca04fe4b.webp"
              alt="Birsa Munda International Hockey Stadium entrance and spectator pavilion, Rourkela"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-sky-900 flex items-center gap-1.5 shadow-sm">
              <Trophy className="w-3.5 h-3.5 text-amber-500" />
              <span>Guinness World Record • 20,011 All-Seater</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-sky-300 font-semibold uppercase tracking-wider">
                FIH Odisha Men\'s Hockey World Cup 2023 Host
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Birsa Munda International Hockey Stadium</h4>
              <p className="text-xs text-slate-300">Sector 15 / BPUT Campus, Rourkela, Odisha</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 text-sky-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>World\'s Largest All-Seater Field Hockey Stadium</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Birsa Munda Hockey Stadium: Global Sports Icon
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Constructed in a record <strong>15 months</strong> to co-host the <strong>FIH Men\'s Hockey World Cup 2023</strong> alongside Bhubaneswar, this magnificent stadium is officially certified by the Guinness World Records as the world\'s largest all-seater hockey venue with <strong>20,011 individual seats</strong>. Equipped with Olympic-category Category-1 certified astro-turf, grand spectator entry staircases, player dugouts, and the World Cup Hockey Village with luxury athlete cottages.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Official Seating Capacity</span>
              <strong className="text-slate-800 text-sm">20,011 All-Seater</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Turf Specification</span>
              <strong className="text-slate-800 text-sm">FIH Category 1 Global Turf</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Public Spectator Entry</span>
              <strong className="text-emerald-700 text-sm">East, West, North, South Stands</strong>
            </div>

            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-slate-400 block mb-0.5 font-medium">Campus Location</span>
              <strong className="text-slate-800">BPUT Campus, Sector 15 / Nayabazar</strong>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <a
              href="https://www.google.com/maps/dir/?api=1&destination=22.2345,84.8080"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-colors"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Get Directions to Stadium ↗</span>
            </a>

            {stadiumItem && (
              <>
                <button
                  onClick={() => onLocateOnMap(stadiumItem)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-white text-slate-700 font-semibold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <MapPin className="w-3.5 h-3.5 text-sky-600" />
                  <span>Locate on Interactive Map</span>
                </button>

                <button
                  onClick={() => onSelectItem(stadiumItem)}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors"
                >
                  <span>Full Profile & Details →</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
