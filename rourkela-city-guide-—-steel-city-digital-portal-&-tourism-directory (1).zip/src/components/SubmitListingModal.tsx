import React, { useState } from 'react';
import { 
  X, 
  PlusCircle, 
  CheckCircle2, 
  Building2, 
  MapPin, 
  Phone, 
  Mail, 
  Globe, 
  AlertCircle 
} from 'lucide-react';
import { CategoryType, LocalityType, DirectoryItem } from '../types/directory';
import { validateSubmission, SubmissionFormPayload } from '../utils/directoryUtils';

interface SubmitListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  prefillItem?: DirectoryItem | null;
  onListingAdded: (item: DirectoryItem) => void;
}

export const SubmitListingModal: React.FC<SubmitListingModalProps> = ({
  isOpen,
  onClose,
  prefillItem,
  onListingAdded
}) => {
  if (!isOpen) return null;

  const [formData, setFormData] = useState<Partial<SubmissionFormPayload>>({
    businessName: prefillItem ? prefillItem.name : '',
    category: prefillItem ? prefillItem.category : 'restaurants',
    locality: prefillItem ? prefillItem.locality : 'Civil Township',
    address: prefillItem ? prefillItem.address : '',
    phone: prefillItem ? prefillItem.phone || '' : '',
    contactEmail: '',
    description: prefillItem ? prefillItem.description : '',
    isOwnerOrOfficial: false,
  });

  const [highlightsInput, setHighlightsInput] = useState('');
  const [websiteInput, setWebsiteInput] = useState(prefillItem?.website || '');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const validation = validateSubmission(formData);
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});

    // Create new DirectoryItem
    const highlights = highlightsInput
      ? highlightsInput.split(',').map(s => s.trim()).filter(Boolean)
      : ['Verified by community submission'];

    const newItem: DirectoryItem = {
      id: `user-sub-${Date.now()}`,
      name: formData.businessName!.trim(),
      category: formData.category as CategoryType,
      subcategory: `${formData.category?.toUpperCase()} • Community Submission`,
      locality: formData.locality as LocalityType,
      address: formData.address!.trim(),
      coordinates: prefillItem ? prefillItem.coordinates : [22.2492, 84.8512], // Rourkela center fallback
      phone: formData.phone!.trim(),
      website: websiteInput.trim() || undefined,
      rating: 4.5,
      reviewsCount: 1,
      verified: false,
      verifiedDate: new Date().toISOString().split('T')[0],
      description: formData.description!.trim(),
      highlights: highlights.length > 0 ? highlights : ['Local Service Listing'],
      timing: 'Hours upon verification',
      priceRange: '₹₹',
      tags: ['CommunityListing', formData.locality || 'Rourkela', formData.category || 'Directory'],
      imageUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&auto=format&fit=crop&q=80'
    };

    // Save to localStorage
    try {
      const existing = localStorage.getItem('rourkela_user_submissions');
      const parsed = existing ? JSON.parse(existing) : [];
      parsed.push(newItem);
      localStorage.setItem('rourkela_user_submissions', JSON.stringify(parsed));
    } catch (err) {
      console.warn('LocalStorage unavailable', err);
    }

    onListingAdded(newItem);
    setIsSuccess(true);
  };

  const handleResetAndClose = () => {
    setIsSuccess(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div 
        className="relative bg-white rounded-3xl max-w-xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] flex flex-col"
        role="dialog"
      >
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 shrink-0 relative">
          <button
            onClick={handleResetAndClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 text-xs font-semibold mb-2">
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Community City Directory Submissions</span>
          </div>

          <h3 className="text-xl sm:text-2xl font-bold tracking-tight font-display">
            {prefillItem ? `Suggest Edit: ${prefillItem.name}` : 'List Your Business or Institution'}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Submit verified details for schools, clinics, restaurants, shops, or services to be featured on Rourkela City Guide.
          </p>
        </div>

        {/* Success View */}
        {isSuccess ? (
          <div className="p-8 text-center my-auto">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h4 className="text-xl font-bold text-slate-900 mb-2">Submission Received!</h4>
            <p className="text-xs text-slate-600 max-w-md mx-auto mb-6 leading-relaxed">
              Thank you for contributing to Rourkela's open digital city directory. Your entry has been loaded into your local session catalog and will appear marked with "Community Submitted" until editorial review.
            </p>
            <button
              onClick={handleResetAndClose}
              className="px-6 py-2.5 bg-slate-900 text-white font-semibold rounded-xl text-xs hover:bg-slate-800 transition-colors"
            >
              Return to Directory
            </button>
          </div>
        ) : (
          /* Form View */
          <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-4">
            {/* Business Name */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Establishment / Business Name *
              </label>
              <input
                type="text"
                value={formData.businessName}
                onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                placeholder="e.g., Ispat Diagnostic Centre, Green Valley Restaurant..."
                className={`w-full px-3 py-2 text-xs rounded-xl border ${
                  errors.businessName ? 'border-rose-500 bg-rose-50' : 'border-slate-300 bg-slate-50'
                } focus:outline-none focus:ring-2 focus:ring-sky-500/20`}
              />
              {errors.businessName && (
                <p className="text-[11px] text-rose-600 mt-1">{errors.businessName}</p>
              )}
            </div>

            {/* Category & Locality */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Directory Category *
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-slate-50 text-slate-800 focus:outline-none"
                >
                  <option value="schools">Schools & Pre-schools</option>
                  <option value="colleges">Colleges & Universities</option>
                  <option value="hospitals">Hospitals & Clinics</option>
                  <option value="restaurants">Restaurants & Cafes</option>
                  <option value="hotels">Hotels & Lodging</option>
                  <option value="shopping">Shopping & Daily Services</option>
                  <option value="industry">Industry & Fabrication</option>
                  <option value="attractions">Tourist Places</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Neighbourhood / Locality *
                </label>
                <select
                  value={formData.locality}
                  onChange={(e) => setFormData({ ...formData, locality: e.target.value as any })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-slate-50 text-slate-800 focus:outline-none"
                >
                  <option value="Civil Township">Civil Township</option>
                  <option value="Uditnagar">Uditnagar</option>
                  <option value="Chhend Colony">Chhend Colony</option>
                  <option value="Koel Nagar">Koel Nagar</option>
                  <option value="Basanti Colony">Basanti Colony</option>
                  <option value="Sector 1-20 (Steel Township)">Sector 1-20</option>
                  <option value="Panposh">Panposh</option>
                  <option value="Jagda">Jagda</option>
                  <option value="Bondamunda">Bondamunda</option>
                  <option value="Kalunga">Kalunga</option>
                  <option value="Fertilizer Township">Fertilizer Township</option>
                  <option value="Birsa Munda / Nayabazar Area">Birsa Munda Area</option>
                  <option value="Wider Sundargarh">Wider Sundargarh</option>
                </select>
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Full Physical Address or Prominent Landmark *
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="e.g., Plot 14, Near Kachery Road, Civil Township, Rourkela"
                className={`w-full px-3 py-2 text-xs rounded-xl border ${
                  errors.address ? 'border-rose-500 bg-rose-50' : 'border-slate-300 bg-slate-50'
                } focus:outline-none`}
              />
              {errors.address && (
                <p className="text-[11px] text-rose-600 mt-1">{errors.address}</p>
              )}
            </div>

            {/* Phone & Email */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Official Phone / Landline *
                </label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="e.g., 0661-2400888 or +91 94370..."
                  className={`w-full px-3 py-2 text-xs rounded-xl border ${
                    errors.phone ? 'border-rose-500 bg-rose-50' : 'border-slate-300 bg-slate-50'
                  } focus:outline-none`}
                />
                {errors.phone && (
                  <p className="text-[11px] text-rose-600 mt-1">{errors.phone}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Verification Contact Email *
                </label>
                <input
                  type="email"
                  value={formData.contactEmail}
                  onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                  placeholder="name@business.com"
                  className={`w-full px-3 py-2 text-xs rounded-xl border ${
                    errors.contactEmail ? 'border-rose-500 bg-rose-50' : 'border-slate-300 bg-slate-50'
                  } focus:outline-none`}
                />
                {errors.contactEmail && (
                  <p className="text-[11px] text-rose-600 mt-1">{errors.contactEmail}</p>
                )}
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Description of Services & Offerings *
              </label>
              <textarea
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe your courses, menu, treatments, services, opening hours, facilities..."
                className={`w-full px-3 py-2 text-xs rounded-xl border ${
                  errors.description ? 'border-rose-500 bg-rose-50' : 'border-slate-300 bg-slate-50'
                } focus:outline-none`}
              />
              {errors.description && (
                <p className="text-[11px] text-rose-600 mt-1">{errors.description}</p>
              )}
            </div>

            {/* Highlights */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Key Highlights (Comma separated)
              </label>
              <input
                type="text"
                value={highlightsInput}
                onChange={(e) => setHighlightsInput(e.target.value)}
                placeholder="e.g., Free Home Delivery, AC Hall, Parking Available, 24/7 Service"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-slate-50 focus:outline-none"
              />
            </div>

            {/* Verification Checkbox */}
            <div className="flex items-start gap-2 pt-2">
              <input
                type="checkbox"
                id="owner-chk"
                checked={formData.isOwnerOrOfficial}
                onChange={(e) => setFormData({ ...formData, isOwnerOrOfficial: e.target.checked })}
                className="mt-0.5 rounded text-sky-600 focus:ring-sky-500"
              />
              <label htmlFor="owner-chk" className="text-xs text-slate-600 leading-normal">
                I confirm that the details provided above are authentic and can be verified against official trade license or institution records.
              </label>
            </div>

            {/* Submit Button */}
            <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-200">
              <button
                type="button"
                onClick={handleResetAndClose}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-md transition-colors"
              >
                Submit Listing for Verification
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
