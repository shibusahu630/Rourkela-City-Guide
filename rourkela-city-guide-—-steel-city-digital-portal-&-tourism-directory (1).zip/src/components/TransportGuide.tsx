import React from 'react';
import { 
  Train, 
  Plane, 
  Bus, 
  Car, 
  MapPin, 
  ExternalLink, 
  CheckCircle2, 
  Clock, 
  Navigation,
  Compass
} from 'lucide-react';

export const TransportGuide: React.FC = () => {
  const trainHighlights = [
    {
      name: 'Rourkela - Puri Vande Bharat Express',
      trainNo: '20835 / 20836',
      route: 'Rourkela -> Jharsuguda -> Sambalpur -> Bhubaneswar -> Cuttack -> Puri',
      features: 'High-speed semi-high speed executive chair car, onboard meals, 7.5 hrs journey',
      status: 'Daily (except Saturdays)'
    },
    {
      name: 'Howrah - Rourkela Vande Bharat Express',
      trainNo: '20871 / 20872',
      route: 'Howrah (HWH) <-> Tatanagar (TATA) <-> Chakradharpur <-> Rourkela (ROU)',
      features: 'Connects Kolkata commercial hub in ~4 hrs 15 mins',
      status: '6 Days a week'
    },
    {
      name: 'Gitanjali Express & Howrah Mumbai Mail',
      trainNo: '12859 / 12860',
      route: 'Howrah <-> Rourkela <-> Nagpur <-> Mumbai CSMT',
      features: 'Crucial daily superfast express linking East to West coast trunk line',
      status: 'Daily 24/7'
    }
  ];

  const intercityRoutes = [
    { destination: 'Bhubaneswar (State Capital)', distance: '325 km', travelTime: '5h 30m by Vande Bharat / 7h by Bus / 45m by Flight', highway: 'NH-149 / Biju Expressway' },
    { destination: 'Jharsuguda (VSS Airport Hub)', distance: '120 km', travelTime: '1h 15m by Train / 1h 45m by Car via 4-lane expressway', highway: 'Biju Expressway (SH-10 / NH-49)' },
    { destination: 'Ranchi (Jharkhand Capital)', distance: '170 km', travelTime: '3h 30m by Train / 4h by AC Coach via Hatia', highway: 'NH-143 / AH46' },
    { destination: 'Sambalpur (Western Hub)', distance: '150 km', travelTime: '2h by Train / 2h 45m by Bus', highway: 'Biju Expressway Corridor' },
    { destination: 'Jamshedpur / Tatanagar', distance: '165 km', travelTime: '2h 15m by Express Train / 3h 30m by Road', highway: 'Howrah-Mumbai Main Trunk' },
  ];

  return (
    <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-slate-200">
      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-100 text-cyan-800 text-xs font-bold mb-2">
          <Train className="w-3.5 h-3.5" />
          <span>Complete City Transit & Connectivity Guide</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
          Railway, Airport & City Transportation
        </h2>
        <p className="text-sm text-slate-600 mt-1 max-w-2xl">
          Comprehensive transit details for Rourkela Junction (ROU), local commercial airport (RRK), domestic gateway Jharsuguda (JRG), and city Mo Bus routes.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
        {/* Railway Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center mb-4">
              <Train className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-lg font-bold text-slate-900">Rourkela Junction</h3>
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-sky-100 text-sky-800">ROU</span>
            </div>
            <p className="text-xs text-slate-500 mb-4">Howrah–Mumbai Main Trunk Line</p>

            <ul className="space-y-2.5 text-xs text-slate-600 mb-6">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>5 High-level platforms with lifts, escalators, and executive AC lounges.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Daily Vande Bharat Express to Bhubaneswar/Puri and Howrah.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>24/7 Computerized reservation counters & Jan Aahar dining.</span>
              </li>
            </ul>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">Enquiry: <strong>139</strong></span>
            <a
              href="https://www.irctc.co.in"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-bold text-sky-600 hover:text-sky-800 flex items-center gap-1"
            >
              IRCTC Booking ↗
            </a>
          </div>
        </div>

        {/* Airport Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center mb-4">
              <Plane className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-lg font-bold text-slate-900">Rourkela Airport</h3>
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">RRK</span>
            </div>
            <p className="text-xs text-slate-500 mb-4">Sector 14 / Airport Road (UDAN)</p>

            <ul className="space-y-2.5 text-xs text-slate-600 mb-6">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Commercial flights to Bhubaneswar (BBI) operated by Alliance Air.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>15 minutes from Steel Township and Birsa Munda Stadium.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Alternate gateway: Veer Surendra Sai Airport Jharsuguda (JRG - 120 km) for flights to Delhi, Bengaluru, Mumbai.</span>
              </li>
            </ul>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">Operator: <strong>AAI / SAIL</strong></span>
            <a
              href="https://www.allianceair.in"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              Alliance Air Flights ↗
            </a>
          </div>
        </div>

        {/* Local City Transit Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-4">
              <Bus className="w-6 h-6" />
            </div>
            <div className="flex items-center justify-between mb-1">
              <h3 className="text-lg font-bold text-slate-900">City Buses & Taxis</h3>
              <span className="text-xs font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">Mo Bus</span>
            </div>
            <p className="text-xs text-slate-500 mb-4">Intra-City & Intercity Mobility</p>

            <ul className="space-y-2.5 text-xs text-slate-600 mb-6">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Mo Bus routes connecting Uditnagar, Civil Township, Chhend, NIT, Panposh.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Auto-rickshaws (metered & shared) available 24/7 at Station Chowk.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>Panposh Intercity Bus Terminal for express coaches across Odisha & Jharkhand.</span>
              </li>
            </ul>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">Terminal: <strong>Panposh & Station</strong></span>
            <a
              href="https://osrtc.in"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-bold text-emerald-600 hover:text-emerald-800 flex items-center gap-1"
            >
              OSRTC Buses ↗
            </a>
          </div>
        </div>
      </div>

      {/* Featured Trains Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs mb-10">
        <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Train className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm font-bold">Featured High-Speed & Superfast Express Trains from Rourkela</h3>
          </div>
          <span className="text-xs text-slate-400">Station Code: ROU</span>
        </div>

        <div className="divide-y divide-slate-100">
          {trainHighlights.map((train, i) => (
            <div key={i} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-slate-900 text-sm">{train.name}</h4>
                  <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-mono font-bold">
                    {train.trainNo}
                  </span>
                </div>
                <p className="text-slate-600 mt-1 font-medium">{train.route}</p>
                <p className="text-slate-400 mt-0.5">{train.features}</p>
              </div>

              <div className="shrink-0 text-right">
                <span className="inline-block bg-emerald-50 text-emerald-700 font-semibold px-2.5 py-1 rounded-md">
                  {train.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Intercity Highways Table */}
      <div>
        <h3 className="text-lg font-bold text-slate-900 mb-3 font-display">
          Key Intercity Highway Travel Times from Rourkela
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {intercityRoutes.map((route, i) => (
            <div key={i} className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-baseline justify-between mb-1">
                <h4 className="font-bold text-slate-900 text-sm">{route.destination}</h4>
                <span className="text-xs font-semibold text-sky-700">{route.distance}</span>
              </div>
              <p className="text-xs text-slate-600 mb-1">{route.travelTime}</p>
              <div className="text-[11px] text-slate-400 flex items-center gap-1">
                <Compass className="w-3 h-3 text-slate-400" />
                <span>Via {route.highway}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
