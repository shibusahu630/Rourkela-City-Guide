import React from 'react';
import { 
  MapPin, 
  Clock, 
  Navigation, 
  CheckCircle2, 
  Sparkles, 
  Phone,
  Mountain,
  Sun,
  Flame,
  ExternalLink,
  Eye,
  Footprints
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';

interface VaishnodeviSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  vaishnodeviItem?: DirectoryItem;
}

export const VaishnodeviSpotlight: React.FC<VaishnodeviSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  vaishnodeviItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-amber-900/10 via-rose-900/5 to-slate-900/5 rounded-3xl p-6 sm:p-8 border border-amber-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[4/3] bg-slate-900 group">
            <img
              src="/assets/aistudio/vaishno-devi-temple_e965b139.jpg"
              alt="Maa Vaishnodevi Temple perched on Durgapur Hill top with white shrine complex overlooking Rourkela Steel City"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-amber-950 flex items-center gap-1.5 shadow-sm">
              <Mountain className="w-3.5 h-3.5 text-amber-600" />
              <span>Durgapur Hilltop • Replica of Holy Trikuta Cave</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-amber-300 font-semibold uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>Holy Pindis Sanctum & Bhairavnath Mandir</span>
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Maa Vaishnodevi Temple & Hill Top</h4>
              <p className="text-xs text-slate-300">Durgapur Hill, Sector 2 / Sector 4, Rourkela Steel Township</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-amber-600" />
            <span>Sacred Hilltop Pilgrimage & 360° City Viewpoint</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Maa Vaishnodevi Temple & Hill Top
          </h3>

          <p className="text-sm text-slate-600 leading-relaxed">
            Perched on the rugged heights of Durgapur Hill, this iconic spiritual landmark replicates the venerated cave shrine of Mata Vaishno Devi in Katra, Jammu & Kashmir. Devotees traverse the natural rock formations to worship the three holy Pindis of Mahakali, Mahalakshmi, and Mahasaraswati inside the sanctum cave, and visit the Bhaironath Temple at the summit, while taking in breathtaking 360-degree panoramic views of Rourkela’s steel township and rolling hills.
          </p>

          {/* Feature Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-amber-700 text-xs font-bold mb-0.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Cave Sanctum</span>
              </div>
              <p className="text-[11px] text-slate-500">Holy Tri-Devi Pindis</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-rose-700 text-xs font-bold mb-0.5">
                <Mountain className="w-3.5 h-3.5 text-rose-600" />
                <span>Bhairavnath Mandir</span>
              </div>
              <p className="text-[11px] text-slate-500">Summit Crest Shrine</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-sky-700 text-xs font-bold mb-0.5">
                <Eye className="w-3.5 h-3.5 text-sky-600" />
                <span>360° Panorama</span>
              </div>
              <p className="text-[11px] text-slate-500">Steel City & Skyline View</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold mb-0.5">
                <Footprints className="w-3.5 h-3.5 text-emerald-600" />
                <span>600+ Steps Climb</span>
              </div>
              <p className="text-[11px] text-slate-500">Paved Trek & Winding Road</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-orange-700 text-xs font-bold mb-0.5">
                <Flame className="w-3.5 h-3.5 text-orange-600" />
                <span>Navratri Mahotsav</span>
              </div>
              <p className="text-[11px] text-slate-500">Devotional Melas & Aarti</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-indigo-700 text-xs font-bold mb-0.5">
                <Clock className="w-3.5 h-3.5 text-indigo-600" />
                <span>Darshan Timings</span>
              </div>
              <p className="text-[11px] text-slate-500">5:30AM–12:30PM • 4–9PM</p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap gap-3">
            <a
              href="tel:06612640112"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs sm:text-sm shadow-sm transition-all"
            >
              <Phone className="w-4 h-4" />
              <span>Temple Trust (0661-2640112)</span>
            </a>

            {vaishnodeviItem && (
              <>
                <button
                  onClick={() => onLocateOnMap(vaishnodeviItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 font-semibold text-xs sm:text-sm border border-slate-300 shadow-2xs transition-all"
                >
                  <MapPin className="w-4 h-4 text-rose-500" />
                  <span>Locate on Map</span>
                </button>

                <button
                  onClick={() => onSelectItem(vaishnodeviItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 font-semibold text-xs sm:text-sm border border-amber-300 shadow-2xs transition-all"
                >
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>View Details & Timings</span>
                </button>
              </>
            )}

            <a
              href="https://maps.google.com/?q=22.2640,84.8590"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs sm:text-sm border border-slate-300 shadow-2xs transition-all"
            >
              <Navigation className="w-4 h-4 text-sky-600" />
              <span>Directions</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
