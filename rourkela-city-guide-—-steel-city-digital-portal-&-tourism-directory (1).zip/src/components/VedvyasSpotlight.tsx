import React from 'react';
import { 
  Compass, 
  MapPin, 
  Clock, 
  Navigation, 
  CheckCircle2, 
  Sparkles, 
  Phone,
  Waves,
  BookOpen,
  Sun,
  Flame,
  ExternalLink
} from 'lucide-react';
import { DirectoryItem } from '../types/directory';

interface VedvyasSpotlightProps {
  onSelectItem: (item: DirectoryItem) => void;
  onLocateOnMap: (item: DirectoryItem) => void;
  vedvyasItem?: DirectoryItem;
}

export const VedvyasSpotlight: React.FC<VedvyasSpotlightProps> = ({
  onSelectItem,
  onLocateOnMap,
  vedvyasItem
}) => {
  return (
    <div className="mb-10 bg-gradient-to-br from-amber-900/10 via-orange-800/5 to-sky-900/5 rounded-3xl p-6 sm:p-8 border border-amber-200/80 shadow-md">
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        {/* Real photo showcase */}
        <div className="relative w-full lg:w-1/2 shrink-0">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2 border-white aspect-[4/3] bg-slate-900 group">
            <img
              src="/assets/aistudio/vedvyas_3a527e47.jpg"
              alt="Vedvyas Temple carved shikhara, bathing ghats, and the holy confluence of Sankha and Koel rivers forming the Brahmani river"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />

            {/* Float badge */}
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-amber-950 flex items-center gap-1.5 shadow-sm">
              <Waves className="w-3.5 h-3.5 text-amber-600" />
              <span>Sacred Triveni Confluence • Birth of Brahmani River</span>
            </div>

            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-[11px] text-amber-300 font-semibold uppercase tracking-wider flex items-center gap-1">
                <BookOpen className="w-3 h-3" />
                <span>Legendary Sage Vyasa Mahabharata Cave</span>
              </p>
              <h4 className="text-lg sm:text-xl font-bold">Vedvyas Temple & River Confluence</h4>
              <p className="text-xs text-slate-300">Panposh, Rourkela, Sundargarh (9 km west of city center)</p>
            </div>
          </div>
        </div>

        {/* Informational description and highlights */}
        <div className="flex-1 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4 text-amber-600" />
            <span>Revered Vedic Pilgrimage & Scenic River Confluence</span>
          </div>

          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight font-display">
            Vedvyas Temple & River Confluence
          </h3>

          <p className="text-sm text-slate-600 leading-relaxed">
            One of the most sacred and visually striking heritage destinations in Odisha. Perched high above the rocky Triveni confluence where the Sankha and Koel rivers meet to birth the majestic Brahmani River. According to revered tradition, Maharshi Krishna Dwaipayana Vyasa meditated in the ancient cave here and composed the immortal epic <em>Mahabharata</em>.
          </p>

          {/* Feature Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1">
            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-amber-700 text-xs font-bold mb-0.5">
                <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                <span>Mahabharata Cave</span>
              </div>
              <p className="text-[11px] text-slate-500">Sage Vyasa Hermitage</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-sky-700 text-xs font-bold mb-0.5">
                <Waves className="w-3.5 h-3.5 text-sky-600" />
                <span>Sankha & Koel</span>
              </div>
              <p className="text-[11px] text-slate-500">Birth of Brahmani River</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-rose-700 text-xs font-bold mb-0.5">
                <Flame className="w-3.5 h-3.5 text-rose-600" />
                <span>Shivaratri Mela</span>
              </div>
              <p className="text-[11px] text-slate-500">10-Day Grand Festival</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-orange-700 text-xs font-bold mb-0.5">
                <Sun className="w-3.5 h-3.5 text-orange-600" />
                <span>Sunrise Ghats</span>
              </div>
              <p className="text-[11px] text-slate-500">Holy Snana & Boating</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold mb-0.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>Vedic Gurukul</span>
              </div>
              <p className="text-[11px] text-slate-500">Sanskrit & Shloka School</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white/80 border border-slate-200/80 shadow-2xs">
              <div className="flex items-center gap-1.5 text-indigo-700 text-xs font-bold mb-0.5">
                <Clock className="w-3.5 h-3.5 text-indigo-600" />
                <span>Open Daily</span>
              </div>
              <p className="text-[11px] text-slate-500">05:00 AM – 08:30 PM</p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-wrap gap-3">
            <a
              href="tel:06612400210"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-xs sm:text-sm shadow-sm transition-all"
            >
              <Phone className="w-4 h-4" />
              <span>Call Temple Trust (0661-2400210)</span>
            </a>

            {vedvyasItem && (
              <>
                <button
                  onClick={() => onSelectItem(vedvyasItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold text-xs sm:text-sm transition-all"
                >
                  <ExternalLink className="w-4 h-4 text-slate-600" />
                  <span>View Darshan & Pilgrimage Details</span>
                </button>

                <button
                  onClick={() => onLocateOnMap(vedvyasItem)}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold text-xs sm:text-sm transition-all"
                >
                  <Navigation className="w-4 h-4 text-amber-600" />
                  <span>Locate Confluence on Map</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
