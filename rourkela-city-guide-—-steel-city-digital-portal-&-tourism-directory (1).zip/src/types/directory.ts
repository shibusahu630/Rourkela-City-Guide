export type CategoryType = 
  | 'all'
  | 'attractions'
  | 'schools'
  | 'colleges'
  | 'hospitals'
  | 'restaurants'
  | 'hotels'
  | 'transport'
  | 'shopping'
  | 'emergency'
  | 'industry';

export type LocalityType = 
  | 'All Localities'
  | 'Civil Township'
  | 'Uditnagar'
  | 'Chhend Colony'
  | 'Koel Nagar'
  | 'Basanti Colony'
  | 'Sector 1-20 (Steel Township)'
  | 'Panposh'
  | 'Jagda'
  | 'Bondamunda'
  | 'Kalunga'
  | 'Fertilizer Township'
  | 'Birsa Munda / Nayabazar Area'
  | 'Wider Sundargarh';

export interface DirectoryItem {
  id: string;
  name: string;
  category: CategoryType;
  subcategory: string;
  locality: LocalityType;
  address: string;
  coordinates: [number, number]; // [lat, lng]
  phone?: string;
  emergencyPhone?: string;
  website?: string;
  rating?: number;
  reviewsCount?: number;
  verified: boolean;
  verifiedDate?: string;
  description: string;
  highlights: string[];
  timing?: string;
  priceRange?: 'Free' | '₹' | '₹₹' | '₹₹₹' | '₹₹₹₹';
  tags: string[];
  imageUrl?: string;
  // Category-specific properties:
  affiliation?: string; // For schools & colleges (CBSE, ICSE, NIT, BPUT, etc.)
  degreesOffered?: string[]; // For colleges
  hostelAvailable?: boolean;
  emergencyAvailable?: boolean; // For healthcare
  cuisine?: string[]; // For restaurants
  dietary?: string[]; // Veg, Non-Veg, Pure Veg
  amenities?: string[]; // For hotels
  transportType?: 'Train' | 'Flight' | 'Bus' | 'Auto' | 'Cab' | 'EV';
  jobOpportunities?: string;
}

export interface CityStat {
  label: string;
  value: string;
  subtext: string;
  source: string;
}

export interface LocalityInfo {
  name: LocalityType;
  pincode: string;
  tagline: string;
  description: string;
  landmark: string;
  transportLinks: string;
  keyFeatures: string[];
}

export interface EventItem {
  id: string;
  title: string;
  category: 'Sports' | 'Festival' | 'Cultural' | 'Exhibition' | 'Industrial';
  date: string;
  venue: string;
  organizer: string;
  description: string;
  ticketInfo: string;
  verifiedDate: string;
}

export interface EmergencyContact {
  service: string;
  category: 'Police' | 'Medical' | 'Fire' | 'Helpline' | 'Disaster' | 'Administration';
  phone: string;
  altPhone?: string;
  available: string;
  address: string;
  notes: string;
}
