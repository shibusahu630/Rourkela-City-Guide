import test from 'node:test';
import assert from 'node:assert/strict';
import {
  filterDirectoryItems,
  getCategoryCounts,
  getLocalityCounts,
  calculateGeoDistance,
  validateSubmission,
  cleanPhoneForDialing
} from './directoryUtils';
import { DirectoryItem } from '../types/directory';

const mockItems: DirectoryItem[] = [
  {
    id: '1',
    name: 'Ispat General Hospital (IGH)',
    category: 'hospitals',
    subcategory: 'Hospital',
    locality: 'Sector 1-20 (Steel Township)',
    address: 'Sector 19, Rourkela',
    coordinates: [22.2475, 84.8765],
    phone: '0661-2642101',
    emergencyPhone: '0661-2642222',
    verified: true,
    description: 'Premier hospital in western Odisha with emergency ward.',
    highlights: ['24/7 Emergency', 'Burn centre'],
    rating: 4.8,
    reviewsCount: 4000,
    tags: ['hospital', 'emergency']
  },
  {
    id: '2',
    name: 'Chandan\'s Fine Dining',
    category: 'restaurants',
    subcategory: 'Restaurant',
    locality: 'Civil Township',
    address: 'Civil Township, Rourkela',
    coordinates: [22.2280, 84.8340],
    phone: '0661-2400838',
    verified: true,
    description: 'North Indian cuisine and biryani.',
    highlights: ['Dum Biryani'],
    rating: 4.5,
    reviewsCount: 2000,
    tags: ['food', 'biryani'],
    dietary: ['Vegetarian', 'Non-Vegetarian']
  },
  {
    id: '3',
    name: 'Hanuman Vatika',
    category: 'attractions',
    subcategory: 'Gardens',
    locality: 'Civil Township',
    address: 'Civil Township, Rourkela',
    coordinates: [22.2312, 84.8362],
    verified: false,
    description: '75-foot statue of Lord Hanuman.',
    highlights: ['Statue', 'Gardens'],
    rating: 4.9,
    reviewsCount: 5000,
    tags: ['temple', 'statue']
  }
];

test('filterDirectoryItems filters by category accurately', () => {
  const result = filterDirectoryItems(mockItems, { category: 'hospitals' });
  assert.equal(result.length, 1);
  assert.equal(result[0].id, '1');
});

test('filterDirectoryItems filters by locality accurately', () => {
  const result = filterDirectoryItems(mockItems, { locality: 'Civil Township' });
  assert.equal(result.length, 2);
});

test('filterDirectoryItems filters by verified status', () => {
  const result = filterDirectoryItems(mockItems, { verifiedOnly: true });
  assert.equal(result.length, 2);
  assert.ok(result.every(i => i.verified));
});

test('filterDirectoryItems searches by query keyword in name, description or tags', () => {
  const result = filterDirectoryItems(mockItems, { query: 'biryani' });
  assert.equal(result.length, 1);
  assert.equal(result[0].id, '2');
});

test('getCategoryCounts computes correct frequencies', () => {
  const counts = getCategoryCounts(mockItems);
  assert.equal(counts.all, 3);
  assert.equal(counts.hospitals, 1);
  assert.equal(counts.restaurants, 1);
  assert.equal(counts.attractions, 1);
});

test('getLocalityCounts computes correct locality breakdown', () => {
  const counts = getLocalityCounts(mockItems);
  assert.equal(counts['All Localities'], 3);
  assert.equal(counts['Civil Township'], 2);
  assert.equal(counts['Sector 1-20 (Steel Township)'], 1);
});

test('calculateGeoDistance returns accurate distance in kilometers', () => {
  // Distance between Hanuman Vatika (22.2312, 84.8362) and Chandan's (22.2280, 84.8340) is ~0.4 - 0.5 km
  const dist = calculateGeoDistance(22.2312, 84.8362, 22.2280, 84.8340);
  assert.ok(dist >= 0.3 && dist <= 0.6, `Expected ~0.4km, got ${dist}`);
});

test('validateSubmission validates missing fields correctly', () => {
  const incomplete = validateSubmission({});
  assert.equal(incomplete.isValid, false);
  assert.ok(incomplete.errors.businessName);
  assert.ok(incomplete.errors.category);
  assert.ok(incomplete.errors.locality);
  assert.ok(incomplete.errors.phone);
  assert.ok(incomplete.errors.contactEmail);

  const complete = validateSubmission({
    businessName: 'Rourkela Steel Fabricators',
    category: 'industry',
    locality: 'Kalunga',
    address: 'Plot 42, Kalunga Industrial Estate',
    phone: '0661-2401800',
    contactEmail: 'contact@kalungafab.in',
    description: 'Manufacturer of industrial steel trusses and fabrication structures.',
    isOwnerOrOfficial: true
  });
  assert.equal(complete.isValid, true);
  assert.equal(Object.keys(complete.errors).length, 0);
});

test('cleanPhoneForDialing strips punctuation and spaces', () => {
  assert.equal(cleanPhoneForDialing('0661-264 2101'), '06612642101');
  assert.equal(cleanPhoneForDialing('+91 80690 49758'), '+918069049758');
  assert.equal(cleanPhoneForDialing('0661-2400108'), '06612400108');
});

test('filterDirectoryItems matches RGH and hospital categories', () => {
  const rghItem: DirectoryItem = {
    id: 'health-rgh-panposh',
    name: 'Rourkela Government Hospital (RGH)',
    category: 'hospitals',
    subcategory: 'Government District Headquarters Hospital',
    locality: 'Panposh',
    address: 'Panposh Road, Rourkela',
    coordinates: [22.2310, 84.8125],
    phone: '0661-2400108',
    verified: true,
    description: 'Principal state government district hospital.',
    highlights: ['BSKY Cashless', '108 Ambulance'],
    rating: 4.1,
    reviewsCount: 2200,
    tags: ['Govt Hospital', 'RGH', 'BSKY', '108 Ambulance'],
    imageUrl: '/assets/aistudio/RGH_1618768712_38ccb2f3.webp'
  };

  const results = filterDirectoryItems([rghItem, ...mockItems], {
    query: 'RGH',
    category: 'all',
    locality: 'All Localities',
    verifiedOnly: false,
    sortBy: 'rating'
  });

  assert.equal(results.length, 1);
  assert.equal(results[0].id, 'health-rgh-panposh');
  assert.equal(results[0].imageUrl, '/assets/aistudio/RGH_1618768712_38ccb2f3.webp');
});

test('filterDirectoryItems matches Vedvyas and river confluence attraction', () => {
  const vedvyasItem: DirectoryItem = {
    id: 'tourist-vedvyas-temple',
    name: 'Vedvyas Temple & River Confluence',
    category: 'attractions',
    subcategory: 'Heritage & Sacred Pilgrimage',
    locality: 'Panposh',
    address: 'Vedvyas, Near Panposh, Rourkela, Odisha 769004',
    coordinates: [22.2435, 84.7780],
    phone: '0661-2400210',
    verified: true,
    description: 'Pilgrimage site at the scenic Triveni confluence of Sankha and Koel rivers.',
    highlights: ['Confluence of Sankha & Koel rivers', 'Ancient Vyasa Cave'],
    rating: 4.7,
    reviewsCount: 9800,
    tags: ['Heritage', 'River Confluence', 'Mahabharata Cave'],
    imageUrl: '/assets/aistudio/vedvyas_3a527e47.jpg'
  };

  const results = filterDirectoryItems([vedvyasItem, ...mockItems], {
    query: 'confluence',
    category: 'attractions',
    locality: 'All Localities',
    verifiedOnly: false,
    sortBy: 'rating'
  });

  assert.equal(results.length, 1);
  assert.equal(results[0].id, 'tourist-vedvyas-temple');
  assert.equal(results[0].imageUrl, '/assets/aistudio/vedvyas_3a527e47.jpg');
});

test('filterDirectoryItems matches Rourkela Steel Plant (SAIL) and authentic image asset', () => {
  const rspItem: DirectoryItem = {
    id: 'tourist-rourkela-steel-plant',
    name: 'Rourkela Steel Plant (SAIL) Heritage & Display',
    category: 'attractions',
    subcategory: 'Industrial Landmark & History',
    locality: 'Sector 1-20 (Steel Township)',
    address: 'SAIL RSP Complex / Main Gate, Rourkela, Odisha 769011',
    coordinates: [22.2200, 84.8650],
    phone: '0661-2510018',
    verified: true,
    description: 'The defining industrial soul of Rourkela. Established in 1955 with German collaboration.',
    highlights: ['Asia pioneer LD process steelmaking plant', 'German-Indian engineering marvel'],
    rating: 4.7,
    reviewsCount: 11200,
    tags: ['Industrial Landmark', 'SAIL Heritage', 'Engineering Marvel', 'Pride of Odisha'],
    imageUrl: '/assets/aistudio/RSP_fa8244eb.jpg'
  };

  const results = filterDirectoryItems([rspItem, ...mockItems], {
    query: 'steel plant',
    category: 'all',
    locality: 'All Localities',
    verifiedOnly: false,
    sortBy: 'rating'
  });

  assert.equal(results.length, 1);
  assert.equal(results[0].id, 'tourist-rourkela-steel-plant');
  assert.equal(results[0].imageUrl, '/assets/aistudio/RSP_fa8244eb.jpg');
});

test('filterDirectoryItems matches Maa Vaishnodevi Temple and authentic image asset', () => {
  const vaishnodeviItem: DirectoryItem = {
    id: 'tourist-vaishnodevi-temple',
    name: 'Maa Vaishnodevi Temple & Hill Top',
    category: 'attractions',
    subcategory: 'Hilltop Shrine & Viewpoint',
    locality: 'Sector 1-20 (Steel Township)',
    address: 'Durgapur Hilltop, Sector 2 / Sector 4 Hill, Rourkela, Odisha 769006',
    coordinates: [22.2640, 84.8590],
    phone: '0661-2640112',
    verified: true,
    description: 'Perched on the scenic crest of Durgapur Hill overlooking the Rourkela steel township. Replica of Katra Vaishno Devi cave shrine.',
    highlights: ['Cave sanctum with holy Pindis', 'Panoramic 360-degree views', 'Bhairavnath Temple at summit'],
    rating: 4.8,
    reviewsCount: 7800,
    tags: ['Hilltop View', 'Sunset Point', 'Temple Cave', 'Skyline', 'Durgapur Hill'],
    imageUrl: '/assets/aistudio/vaishno-devi-temple_e965b139.jpg'
  };

  const results = filterDirectoryItems([vaishnodeviItem, ...mockItems], {
    query: 'vaishnodevi',
    category: 'attractions',
    locality: 'All Localities',
    verifiedOnly: false,
    sortBy: 'rating'
  });

  assert.equal(results.length, 1);
  assert.equal(results[0].id, 'tourist-vaishnodevi-temple');
  assert.equal(results[0].imageUrl, '/assets/aistudio/vaishno-devi-temple_e965b139.jpg');
});

test('filterDirectoryItems matches Mandira Dam & Reservoir and authentic spillway image asset', () => {
  const mandiraItem: DirectoryItem = {
    id: 'tourist-mandira-dam',
    name: 'Mandira Dam & Reservoir',
    category: 'attractions',
    subcategory: 'Scenic Lake & Spillway Dam',
    locality: 'Wider Sundargarh',
    address: 'Sankha River, Mandira, ~16 km West of Rourkela, Kansbahal, Odisha 770034',
    coordinates: [22.2740, 84.6730],
    phone: '0661-2642010',
    verified: true,
    description: 'Constructed across the Sankha river in 1957–1959 by SAIL to supply critical industrial and drinking water to Rourkela Steel Plant.',
    highlights: ['Multi-gate concrete spillway', 'SAIL Rourkela Steel Plant water reservoir', 'Scenic reservoir boating'],
    rating: 4.6,
    reviewsCount: 7100,
    tags: ['Mandira Dam', 'Sankha River', 'Spillway Gates', 'Boating & Lake', 'SAIL Lifeline', 'Picnic Spot'],
    imageUrl: '/assets/aistudio/mandira_4e339f25.jpg'
  };

  const results = filterDirectoryItems([mandiraItem, ...mockItems], {
    query: 'mandira dam',
    category: 'attractions',
    locality: 'All Localities',
    verifiedOnly: false,
    sortBy: 'rating'
  });

  assert.equal(results.length, 1);
  assert.equal(results[0].id, 'tourist-mandira-dam');
  assert.equal(results[0].imageUrl, '/assets/aistudio/mandira_4e339f25.jpg');
});

test('filterDirectoryItems matches Indira Gandhi Park & Musical Fountain and authentic boating lake image asset', () => {
  const igParkItem: DirectoryItem = {
    id: 'tourist-ig-park',
    name: 'Indira Gandhi Park & Musical Fountain',
    category: 'attractions',
    subcategory: 'Urban Botanical Park & Boating Lake',
    locality: 'Sector 1-20 (Steel Township)',
    address: 'Sector 2, Steel Township, Rourkela, Odisha 769006',
    coordinates: [22.2590, 84.8680],
    phone: '0661-2646200',
    verified: true,
    description: 'A sprawling 42-acre botanical wonderland and urban recreation center meticulously nurtured by SAIL Rourkela Steel Plant.',
    highlights: ['Picturesque boating lake with artistic floating boat sculptures', 'Evening dancing musical fountain'],
    rating: 4.5,
    reviewsCount: 8900,
    tags: ['IG Park', 'Musical Fountain', 'Boating Lake', 'Deer Park & Zoo', 'Toy Train', 'Family Recreation'],
    imageUrl: '/assets/aistudio/Indira-Gandhi-Park-Rourkela-Sundargarh_dfe9074a.webp'
  };

  const results = filterDirectoryItems([igParkItem, ...mockItems], {
    query: 'musical fountain',
    category: 'attractions',
    locality: 'All Localities',
    verifiedOnly: false,
    sortBy: 'rating'
  });

  assert.equal(results.length, 1);
  assert.equal(results[0].id, 'tourist-ig-park');
  assert.equal(results[0].imageUrl, '/assets/aistudio/Indira-Gandhi-Park-Rourkela-Sundargarh_dfe9074a.webp');
});

test('filterDirectoryItems matches Pitamahal Dam & Nature Reserve and authentic reservoir image asset', () => {
  const pitamahalItem: DirectoryItem = {
    id: 'tourist-pitamahal-dam',
    name: 'Pitamahal Dam & Nature Reserve',
    category: 'attractions',
    subcategory: 'Eco Lake & Bird Watching',
    locality: 'Wider Sundargarh',
    address: 'Pitamahal River, Kalunga Outskirts, ~18 km South of Rourkela',
    coordinates: [22.2030, 84.7350],
    phone: '0661-2400300',
    verified: true,
    description: 'An expansive scenic reservoir and curved masonry embankment constructed across the Pitamahal River.',
    highlights: ['Curved earthen & masonry dam embankment', 'Tranquil reservoir surrounded by dense sal forest hills'],
    rating: 4.4,
    reviewsCount: 3800,
    tags: ['Pitamahal Dam', 'Eco Lake', 'Bird Watching', 'Dense Sal Forest', 'Kalunga Outskirts', 'Scenic Picnic', 'Nature Escape'],
    imageUrl: '/assets/aistudio/pitamahal_8e4497e1.jpg'
  };

  const results = filterDirectoryItems([pitamahalItem, ...mockItems], {
    query: 'pitamahal',
    category: 'attractions',
    locality: 'All Localities',
    verifiedOnly: false,
    sortBy: 'rating'
  });

  assert.equal(results.length, 1);
  assert.equal(results[0].id, 'tourist-pitamahal-dam');
  assert.equal(results[0].imageUrl, '/assets/aistudio/pitamahal_8e4497e1.jpg');
  assert.ok(results[0].tags.includes('Bird Watching'));
});



