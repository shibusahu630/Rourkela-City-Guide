import { DirectoryItem, CategoryType, LocalityType } from '../types/directory';

export interface FilterOptions {
  query?: string;
  category?: CategoryType;
  locality?: LocalityType | 'All Localities';
  dietary?: string;
  verifiedOnly?: boolean;
  sortBy?: 'name' | 'rating' | 'reviews';
}

export function filterDirectoryItems(
  items: DirectoryItem[],
  options: FilterOptions
): DirectoryItem[] {
  const {
    query = '',
    category = 'all',
    locality = 'All Localities',
    dietary,
    verifiedOnly = false,
    sortBy = 'rating'
  } = options;

  const normalizedQuery = query.trim().toLowerCase();

  const filtered = items.filter(item => {
    // Category check
    if (category !== 'all' && item.category !== category) {
      return false;
    }

    // Locality check
    if (locality !== 'All Localities' && item.locality !== locality) {
      return false;
    }

    // Verified check
    if (verifiedOnly && !item.verified) {
      return false;
    }

    // Dietary check for restaurants
    if (dietary && item.dietary && item.dietary.length > 0) {
      if (!item.dietary.some(d => d.toLowerCase() === dietary.toLowerCase())) {
        return false;
      }
    }

    // Search query check (name, subcategory, address, description, tags, highlights)
    if (normalizedQuery) {
      const matchName = item.name.toLowerCase().includes(normalizedQuery);
      const matchSubcategory = item.subcategory.toLowerCase().includes(normalizedQuery);
      const matchAddress = item.address.toLowerCase().includes(normalizedQuery);
      const matchDesc = item.description.toLowerCase().includes(normalizedQuery);
      const matchTags = item.tags.some(t => t.toLowerCase().includes(normalizedQuery));
      const matchHighlights = item.highlights.some(h => h.toLowerCase().includes(normalizedQuery));

      if (!matchName && !matchSubcategory && !matchAddress && !matchDesc && !matchTags && !matchHighlights) {
        return false;
      }
    }

    return true;
  });

  // Sorting
  return filtered.sort((a, b) => {
    if (sortBy === 'rating') {
      const ratingA = a.rating ?? 0;
      const ratingB = b.rating ?? 0;
      return ratingB - ratingA;
    }
    if (sortBy === 'reviews') {
      const revA = a.reviewsCount ?? 0;
      const revB = b.reviewsCount ?? 0;
      return revB - revA;
    }
    return a.name.localeCompare(b.name);
  });
}

export function getCategoryCounts(items: DirectoryItem[]): Record<string, number> {
  const counts: Record<string, number> = { all: items.length };
  for (const item of items) {
    counts[item.category] = (counts[item.category] || 0) + 1;
  }
  return counts;
}

export function getLocalityCounts(items: DirectoryItem[]): Record<string, number> {
  const counts: Record<string, number> = { 'All Localities': items.length };
  for (const item of items) {
    counts[item.locality] = (counts[item.locality] || 0) + 1;
  }
  return counts;
}

/**
 * Calculates Haversine distance in kilometers between two geo coordinates
 */
export function calculateGeoDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

export interface SubmissionFormPayload {
  businessName: string;
  category: CategoryType;
  locality: LocalityType;
  address: string;
  phone: string;
  contactEmail: string;
  description: string;
  isOwnerOrOfficial: boolean;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export function validateSubmission(data: Partial<SubmissionFormPayload>): ValidationResult {
  const errors: Record<string, string> = {};

  if (!data.businessName || data.businessName.trim().length < 3) {
    errors.businessName = 'Business or establishment name must be at least 3 characters.';
  }

  if (!data.category || data.category === 'all') {
    errors.category = 'Please choose a valid category for your listing.';
  }

  if (!data.locality || data.locality === 'All Localities') {
    errors.locality = 'Please select the neighbourhood/locality in Rourkela.';
  }

  if (!data.address || data.address.trim().length < 5) {
    errors.address = 'Specific address or landmark is required for verification.';
  }

  if (!data.phone || !/^[0-9+\-\s()]{7,15}$/.test(data.phone.trim())) {
    errors.phone = 'Please provide a valid official contact number or landline.';
  }

  if (!data.contactEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.contactEmail.trim())) {
    errors.contactEmail = 'Valid email is required for listing verification updates.';
  }

  if (!data.description || data.description.trim().length < 15) {
    errors.description = 'Please provide a brief description (at least 15 characters).';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

export function cleanPhoneForDialing(phone: string): string {
  return phone.replace(/[^0-9+]/g, '');
}
